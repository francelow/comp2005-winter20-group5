
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.Math;

/**
 * Class that represents a robot with an x and y coordinate
 *
 * @author (Mohammad Hasan 201858685)
 * 
 */
public class Robot //implements ActionListener
{
    private JButton robot;
    private int x;          //actual x position of robot
    private int y;          //actual y position of robot
    private int tempX;      //temporary x position (used for moving robot only)
    private int tempY;      //temporary y position (used for moving robot only)
    private ImageIcon rIcon;        //robot icon
    private int num_of_moves;       //number of moves made by this robot
    private boolean selected = false;       //if the robot is selected or not
    private Icon oldTemp;       //dont worry about this (used in move functions)
    private Icon newTemp;       //dont worry about this either (this too)
    private String color;       //color of the robot
    
    //makes a robot object with the appropriate icon and sets it in a random
    //position that is not a special square or the center of the board
    public Robot(ImageIcon icon)
    {
       //place robot in a random position excluding middle and special squares of the board 
       x = (int)(Math.random()*16);
       y = (int)(Math.random()*16);
       while((x == 7 && y == 7) 
        || (x == 7 && y == 8) 
        || (x == 8 && y == 7) 
        || (x == 8 && y == 8)
        || (x == 1 && y == 4)
        || (x == 1 && y == 13)
        || (x == 3 && y == 1)
        || (x == 3 && y == 9)
        || (x == 4 && y == 6)
        || (x == 5 && y == 14)
        || (x == 6 && y == 3)
        || (x == 6 && y == 11)
        || (x == 8 && y == 5)
        || (x == 9 && y == 1)
        || (x == 9 && y == 14)
        || (x == 10 && y == 4)
        || (x == 10 && y == 8)
        || (x == 11 && y == 13)
        || (x == 13 && y == 5)
        || (x == 13 && y == 10)
        || (x == 14 && y == 3)
        || (x == 1 && y == 4)
        || (x == 1 && y == 10)
        || (x == 3 && y == 1)
        || (x == 4 && y == 6)
        || (x == 4 && y == 8)
        || (x == 5 && y == 13)
        || (x == 6 && y == 2)
        || (x == 6 && y == 3)
        || (x == 6 && y == 13)
        || (x == 7 && y == 5)
        || (x == 7 && y == 11)
        || (x == 9 && y == 2)
        || (x == 9 && y == 10)
        || (x == 10 && y == 7)
        || (x == 11 && y == 12)
        || (x == 11 && y == 13)
        || (x == 12 && y == 3)
        || (x == 12 && y == 6)
        || (x == 12 && y == 9)
        || (x == 13 && y == 1)
        || (x == 13 && y == 3)
        || (x == 13 && y == 9)
        || (x == 14 && y == 5)
        || (x == 14 && y == 11)
        )
        {
            x = (int)(Math.random()*16);
            y = (int)(Math.random()*16);
        }
        
        tempX = x;
        tempY = y;
        //sets robot icon
        rIcon = icon;
    }
    
    //returns the x coordinate of the robot
     public int getXCoord()
    {
        return x;
    }
    
    //returns the y coordinate of the robot
    public int getYCoord()
    {
        return y;
    }
    
    //sets color of the robot
    public void setColor(String color)
    {
        this.color = color;
    }
    
    //returns color of the robot
    public String getColor()
    {
        return color;
    }
    
    
    //returns the icon of the robot
     public ImageIcon getIcon()
    {
        return rIcon;
    }
    
    //changes the status of a robot from selected to unselected and vice versa
    public void changeSelected()
    {
        if(selected)
        selected = false;
        else
        selected = true;
    }
    
    //method used to check if robot is selected or not
    public boolean isSelected()
    {
        return selected;
    }
    
    //FOR EASY MAP ONLY. moves the robot depending on where the user clicked
    public void easyMove(int x, int y)
    {
        if( y < this.y)
        {
            int initialx = this.x;
            int initialy = this.y;
            
            while(!EasyMap.getSquare(this.x,this.y).isLeftWall() &&
            !EasyMap.getSquare(this.x, this.y-1).isOccupied())
            {
               this.y--;
               num_of_moves++;
            }
            
            
            
            if(this.y != initialy)
            {
                oldTemp = newTemp;
                newTemp = EasyMap.getSquare(this.x,this.y).getIcon();
                EasyMap.getSquare(initialx,initialy).changeOccupied();
                EasyMap.changeIcon(initialx,initialy,oldTemp); 
                EasyMap.changeIcon(this.x, this.y, rIcon);        
                EasyMap.getSquare(this.x,this.y).changeOccupied();
            }
        }
        
        else if( y > this.y)
        {   
            int initialx = this.x;
            int initialy = this.y;
            
            while(!EasyMap.getSquare(this.x,this.y).isRightWall() &&
            !EasyMap.getSquare(this.x, this.y+1).isOccupied())
            {
               this.y++;
               num_of_moves++;
            }
            
            
            
            if(this.y != initialy)
            {
                oldTemp = newTemp;
                newTemp = EasyMap.getSquare(this.x,this.y).getIcon();
                EasyMap.getSquare(initialx,initialy).changeOccupied();
                EasyMap.changeIcon(initialx,initialy,oldTemp); 
                EasyMap.changeIcon(this.x, this.y, rIcon);        
                EasyMap.getSquare(this.x,this.y).changeOccupied();
            }
        }
        
        else if( x < this.x)
        {
            int initialx = this.x;
            int initialy = this.y;
            
            while(!EasyMap.getSquare(this.x,this.y).isTopWall() &&
            !EasyMap.getSquare(this.x-1, this.y).isOccupied())
            {
               this.x--;
               num_of_moves++;
            }
            
            
            
            if(this.x != initialx)
            {
                oldTemp = newTemp;
                newTemp = EasyMap.getSquare(this.x,this.y).getIcon();
                EasyMap.getSquare(initialx,initialy).changeOccupied();
                EasyMap.changeIcon(initialx,initialy,oldTemp); 
                EasyMap.changeIcon(this.x, this.y, rIcon);        
                EasyMap.getSquare(this.x,this.y).changeOccupied();
            }
        }
        
        else if( x > this.x)
        {
            int initialx = this.x;
            int initialy = this.y;
            
            while(!EasyMap.getSquare(this.x,this.y).isBottomWall() &&
            !EasyMap.getSquare(this.x+1, this.y).isOccupied())
            {
               this.x++;
               num_of_moves++;
            }
            
            if(this.x != initialx)
            {
                oldTemp = newTemp;
                newTemp = EasyMap.getSquare(this.x,this.y).getIcon();
                EasyMap.getSquare(initialx,initialy).changeOccupied();
                EasyMap.changeIcon(initialx,initialy,oldTemp);
                EasyMap.changeIcon(this.x, this.y, rIcon);        
                EasyMap.getSquare(this.x,this.y).changeOccupied();
            }
        }
    }
    
    //FOR DIFFICULT MAP ONLY. moves the robot depending on where the user clicked
    public void diffMove(int x, int y)
    {
        if( y < tempY)
        {          
            while(!DifficultMap.getSquare(tempX,tempY).isLeftWall() &&
            !DifficultMap.getSquare(tempX, tempY-1).isOccupied() &&
            !DifficultMap.getSquare(tempX, tempY).getDiagonalColor().equals(color))
            {
               tempY--;
               num_of_moves++;
            }
            
            if(DifficultMap.getSquare(tempX, tempY).getDiagonalColor().equals(color))
            {
                changeDirection("left", tempX, tempY);
            }
            
            
            if(tempY != this.y)
            {
                oldTemp = newTemp;
                newTemp = DifficultMap.getSquare(tempX,tempY).getIcon();
                DifficultMap.getSquare(this.x,this.y).changeOccupied();
                DifficultMap.changeIcon(this.x,this.y,oldTemp); 
                DifficultMap.changeIcon(tempX, tempY, rIcon);        
                DifficultMap.getSquare(tempX,tempY).changeOccupied();
                this.x = tempX;
                this.y = tempY;
            }
        }
        
        else if( y > tempY)
        {   
            while(!DifficultMap.getSquare(tempX,tempY).isRightWall() &&
            !DifficultMap.getSquare(tempX,tempY+1).isOccupied() &&
            !DifficultMap.getSquare(tempX,tempY).getDiagonalColor().equals(color))
            {
               tempY++;
               num_of_moves++;
            }
            
            if(DifficultMap.getSquare(tempX,tempY).getDiagonalColor().equals(color))
            {
                changeDirection("right", tempX,tempY);
            }

            
            if(tempY != this.y)
            {
                oldTemp = newTemp;
                newTemp = DifficultMap.getSquare(tempX,tempY).getIcon();
                DifficultMap.getSquare(this.x,this.y).changeOccupied();
                DifficultMap.changeIcon(this.x,this.y,oldTemp); 
                DifficultMap.changeIcon(tempX,tempY, rIcon);        
                DifficultMap.getSquare(tempX,tempY).changeOccupied();
                this.x = tempX;
                this.y = tempY; 
            }
        }
        
        else if( x < tempX)
        {
            while(!DifficultMap.getSquare(tempX,tempY).isTopWall() &&
            !DifficultMap.getSquare(tempX-1,tempY).isOccupied() &&
            !DifficultMap.getSquare(tempX,tempY).getDiagonalColor().equals(color))
            {
               tempX--;
               num_of_moves++;
            }
            
            if(DifficultMap.getSquare(tempX,tempY).getDiagonalColor().equals(color))
            {
                changeDirection("up", tempX,tempY);
            }
            
            
            if(tempX != this.x)
            {
                oldTemp = newTemp;
                newTemp = DifficultMap.getSquare(tempX,tempY).getIcon();
                DifficultMap.getSquare(this.x,this.y).changeOccupied();
                DifficultMap.changeIcon(this.x,this.y,oldTemp); 
                DifficultMap.changeIcon(tempX,tempY, rIcon);        
                DifficultMap.getSquare(tempX,tempY).changeOccupied();
                this.x = tempX;
                this.y = tempY;
            }
        }
        
        else if( x > tempX)
        { 
            while(!DifficultMap.getSquare(tempX,tempY).isBottomWall() &&
            !DifficultMap.getSquare(tempX+1,tempY).isOccupied() &&
            !DifficultMap.getSquare(tempX,tempY).getDiagonalColor().equals(color))
            {
               tempX++;
               num_of_moves++;
            }
            
            if(DifficultMap.getSquare(tempX,tempY).getDiagonalColor().equals(color))
            {
                changeDirection("down", tempX,tempY);
            }
            
            
            if(tempX != this.x)
            {
                oldTemp = newTemp;
                newTemp = DifficultMap.getSquare(tempX,tempY).getIcon();
                DifficultMap.getSquare(this.x,this.y).changeOccupied();
                DifficultMap.changeIcon(this.x,this.y,oldTemp);
                DifficultMap.changeIcon(tempX,tempY, rIcon);        
                DifficultMap.getSquare(tempX,tempY).changeOccupied();
                this.x = tempX;
                this.y = tempY;
            }
        }
    }
    
    //changes the direction of the robot when it comes across a diagonal wall
    public void changeDirection(String direction, int x, int y)
    {
        if(direction.equals("left"))
        {
            if(color.equals("green") || color.equals("red"))
            {
                tempX++;
                num_of_moves++;
                x+=2;
                if(x>15)
                    x=15;
                diffMove(x,y);
            }
            else
            {   
                tempX--;
                num_of_moves++;
                x-=2;
                if(x<0)
                    x=0;
                diffMove(x,y);
            }
        }
        
        if(direction.equals("right"))
        {
            if(color.equals("green") || color.equals("red"))
            {
                tempX--;
                num_of_moves++;
                x-=2;
                if(x<0)
                    x=0;
                diffMove(x,y);
            }
            else
            {
                tempX++;
                num_of_moves++;
                x+=2;
                if(x>15)
                    x=15;
                diffMove(x,y);
            }
        }
        
        if(direction.equals("up"))
        {
            if(color.equals("green") || color.equals("red"))
            {
                tempY++;
                num_of_moves++;
                y+=2;
                if(y>15)
                    y=15;
                diffMove(x,y);
            }
            else
            {
                tempY--;
                num_of_moves++;
                y-=2;
                if(y<0)
                    y=0;
                diffMove(x,y);
            }
        }
        
        if(direction.equals("down"))
        {
            if(color.equals("green") || color.equals("red"))
            {
                tempY--;
                num_of_moves++;
                y-=2;
                if(y<0)
                    y=0;
                diffMove(x,y);
            }
            else
            {
                tempY++;
                num_of_moves++;
                y+=2;
                if(y>15)
                    y=15;
                diffMove(x,y);
            }
        }
    }
    
    //returns total number of moves made by this robot
    public int getNum_Of_Moves()
    {
        return num_of_moves;
    }   
    
    public void actionPerformed(ActionEvent aevt)
    {
        if(aevt.getSource() == rIcon){
         changeSelected();
        }
    }
}
