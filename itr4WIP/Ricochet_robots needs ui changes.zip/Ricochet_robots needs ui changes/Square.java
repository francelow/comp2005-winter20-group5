import javax.swing.*;
/**
 * Square class that represents a specific square on the board with an x and y
 * coordinate and other charectaristics
 * @author (Mohammad Hasan201858685)
 * @version (a version number or a date)
 */
public class Square extends JButton
{
    private int xCoord;  //x coordinate
    private int yCoord;  //y coordinate
    private boolean topWall, bottomWall, leftWall, rightWall, diagonalWall;
    private boolean occupied;
    private String diagonalColor;
    private Icon squareIcon;
    private String specialSquare;
    private boolean isGoal;
   
    public Square()
    {
       super();
       topWall = false;
       bottomWall= false;
       leftWall = false;
       rightWall = false;
       specialSquare = null;
       occupied = false;
       diagonalColor = "gray";
       isGoal = false;
    }
    
    //checks if square has a wall on the left
    public boolean isLeftWall()
    {
        return leftWall;
    }
    
    //checks if square has a wall on the right
    public boolean isRightWall()
    {
        return rightWall;
    }
    
    //checks if square has a wall on top
    public boolean isTopWall()
    {
        return topWall;
    }
    
    //checks if square has a wall on the bottom
    public boolean isBottomWall()
    {
        return bottomWall;
    }
    
    public boolean isDiagonalWall()
    {
        return diagonalWall;
    }
    
    //sets the square to have a wall on top
     public void setTopWall(boolean bool)
    {
        topWall = bool;
    }
    
    //sets the square to have a wall on the bottom
    public void setBottomWall(boolean bool)
    {
        bottomWall = bool;
    }
    
    //sets the square to have a wall on the left
    public void setLeftWall(boolean bool)
    {
        leftWall = bool;
    }
    
    //sets the square to have a wall on the right
    public void setRightWall(boolean bool)
    {
        rightWall = bool;
    }
    
    public void setDiagonalWall(boolean bool, String color)
    {
        diagonalWall = bool; diagonalColor = color;
    }
    
    public String getDiagonalColor()
    {
        return diagonalColor;
    }
    
    //returns the icon of the square
    public Icon getIcon()
    {
        return squareIcon; 
    }
   
    //sets the icon of the square
    public void setIcons(Icon icon)
    {
        squareIcon = icon;
    }
    
    //checks if the square is currently occupied by a robot
    public boolean isOccupied()
    {
       return occupied;
    }
    
    //changes the status of the square to reflect if there is a robot on it or not
    public void changeOccupied()
    {
        if(occupied)
        occupied = false;
        else
        occupied = true;
    }
    
    //returns the y coordinate of the square
    public int getYCoord()
    {
        return yCoord;
    }
    
    //returns the x coordinate of the square
    public int getXCoord()
    {
        return xCoord;
    }
    
    public void setX(int x)
    {
        xCoord = x;
    }
    
    public void setY(int y)
    {
        yCoord = y;
    }

    //makes the square into a special square. Squares that have no special 
    //charecteristic (basic squares) have null in the speicalSquare variable
    public void setSpecialSquare(String spec)
    {
        specialSquare = spec;
    }
    
    public String getSpecialSquare()
    {
        return specialSquare;
    }
    
    public void setIsGoal()
    {
        isGoal = true;
    }
    
    public void resetGoal()
    {
        isGoal = false;
    }
    
    public Boolean getIsGoal()
    {
        return isGoal;
    }
}
