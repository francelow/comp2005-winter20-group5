import java.awt.*;
import javax.swing.*;

/**
 * Driver class that starts the Main Menu class
 *
 * @author Mohammad Hasan (201858685)
 * @version 0.1
 */
public class Driver
{
    public static void main(String[] args) 
    {       
        new MainMenu();
    }
}
