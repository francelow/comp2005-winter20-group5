
/**
 * Write a description of class NewRound here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class NewRound
{
    private EasyMap map;
    private int goal;
    /**
     * Constructor for objects of class NewRound
     */
    public NewRound(EasyMap map)
    {
        this.map = map;
        goal = (int)(Math.random()*16);
    }
    
    public void newGoal()
    {
        
    }
    
    



}
