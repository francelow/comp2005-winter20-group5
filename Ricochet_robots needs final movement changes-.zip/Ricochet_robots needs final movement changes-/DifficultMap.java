import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.Color;
import java.util.*;

/**
 * Write a description of class ComplexMap here.
 *
 * @author (Mohammad Hasan 201858685,Jabulani Mabena 201820578)

 */
public class DifficultMap extends JFrame implements ActionListener, MouseListener
{
   private JPanel west;
    private JPanel east;
    private static Square[][] boardSquares;
    private Robot redRobot;
    private Robot blueRobot;
    private Robot greenRobot;
    private Robot yellowRobot;
    private JLabel selectedRobot;
    private JLabel currPlayer;
    private JLabel moves;
    private int num_of_players;
    private JLabel player1;
    private JLabel player2;
    private JLabel player3;
    private JLabel player4;
    private int totalMoves;
    private ArrayList<Square> specials;
    private Square Goal;
    private Player players[];
    private Player currentPlayer;
    private Player LastPlayer;
    private Player roundWinner;
    private int maxMoves = 45;
    private int rx,ry,yx,yy,gx,gy,bx,by;
    
    public DifficultMap(int num_of_players)
    {
        super("Ricochet Robots Easy");
        
        this.num_of_players = num_of_players;
        totalMoves = 0;
        players = new Player[num_of_players];
        createPlayers();
        
        //Panel where the board will be placed
        west = new JPanel();
        east = new JPanel();
        
        west.setLayout(new GridLayout(16,16));
        east.setLayout(new GridLayout(0,1));
        
        //if color vision support is selected then show the color vision supported board or else show board with normal colors
        if(!MainMenu.isColorVision())
        {
            makeBoard(); makeRightPanel(); makeWalls(); makeSpecialSquares(); setMapEdgeWall(); 
            makeMiddleSquares(); setRobot(); newGoal(); resetPlayers(); changePlayer();
        }
        else
        {
            makeColorVisionBoard(); makeRightPanel(); makeColorVisionWalls(); makeColorVisionSpecialSquares(); setMapEdgeWall(); 
            makeMiddleSquares(); setColorVisionRobot(); newGoal(); resetPlayers(); changePlayer();
        }
        
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(west, BorderLayout.WEST);
        getContentPane().add(east, BorderLayout.EAST);
        
        setPreferredSize(new Dimension(850, 750));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true); 
}

// makes board with normal colors
    public void makeBoard()
    {
        Icon basicSquare = new ImageIcon(((new ImageIcon("Resources/basicSquare.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares = new Square[16][16];
        for(int column = 0; column <16; column++)
        {
            for(int row=0; row <16; row++)
            {
                boardSquares[column][row] = new Square();
                boardSquares[column][row].setX(column);
                boardSquares[column][row].setY(row);
                boardSquares[column][row].setIcon(basicSquare);
                boardSquares[column][row].setSpecialSquare(null);
                boardSquares[column][row].setSize(50,50);
                boardSquares[column][row].setIcons(basicSquare);               
                boardSquares[column][row].setOpaque(true);
                boardSquares[column][row].addActionListener(this);
                boardSquares[column][row].addMouseListener(this);
                boardSquares[column][row].setBorderPainted(false);
                boardSquares[column][row].setBorder(BorderFactory.createEmptyBorder());
                boardSquares[column][row].setBackground(Color.GRAY); 
                west.add(boardSquares[column][row]);
            }
        }
    }
    
    public void makeRightPanel()
    {
        moves = new JLabel("Moves: 0");
        currPlayer = new JLabel("Player: None");
        selectedRobot = new JLabel("Robot selected: None");
        
         if(num_of_players == 1)
        {
            player1 = new JLabel("Player 1: ");
            east.add(player1);
        }
        
        if(num_of_players == 2)
        {
            player1 = new JLabel("Player 1: ");
            player2 = new JLabel("Player 2: ");
            east.add(player1);
            east.add(player2);
        }
        
        if(num_of_players == 3)
        {
            player1 = new JLabel("Player 1: ");
            player2 = new JLabel("Player 2: ");
            player3 = new JLabel("Player 3: ");
            east.add(player1);
            east.add(player2);
            east.add(player3);
        }
        
        if(num_of_players == 4)
        {
            player1 = new JLabel("Player 1: ");
            player2 = new JLabel("Player 2: ");
            player3 = new JLabel("Player 3: ");
            player4 = new JLabel("Player 4: ");
            east.add(player1);
            east.add(player2);
            east.add(player3);
            east.add(player4);
        }
        
        east.add(currPlayer);
        east.add(moves);
        east.add(selectedRobot);
    }
    
    // makes color vision assisted board
    public void makeColorVisionBoard()
    {
        Icon basicSquare = new ImageIcon(((new ImageIcon("Resources/Assisted/basicSquare.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares = new Square[16][16];
        for(int column = 0; column <16; column++)
        {
            for(int row=0; row <16; row++)
            {
                boardSquares[column][row] = new Square();
                boardSquares[column][row].setX(column);
                boardSquares[column][row].setY(row);
                boardSquares[column][row].setSpecialSquare(null);
                boardSquares[column][row].setIcon(basicSquare);
                boardSquares[column][row].setSize(50,50);
                boardSquares[column][row].setIcons(basicSquare);               
                boardSquares[column][row].setOpaque(true);
                boardSquares[column][row].addActionListener(this);
                boardSquares[column][row].addMouseListener(this);
                boardSquares[column][row].setBorderPainted(false);
                boardSquares[column][row].setBorder(BorderFactory.createEmptyBorder());
                boardSquares[column][row].setBackground(Color.GRAY); 
                west.add(boardSquares[column][row]);
            }
        }
    }
    
    //making specific spaces have the charectaristics of a wall
    public void makeWalls()
    {
        Icon leftWall = new ImageIcon(((new ImageIcon("Resources/leftWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon topWall = new ImageIcon(((new ImageIcon("Resources/topWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon bottomWall = new ImageIcon(((new ImageIcon("Resources/bottomWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon rightWall = new ImageIcon(((new ImageIcon("Resources/rightWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon redDiagonalWall = new ImageIcon(((new ImageIcon("Resources/Difficult/redDiagonal.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH)); 
        Icon blueDiagonalWall = new ImageIcon(((new ImageIcon("Resources/Difficult/blueDiagonal.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH)); 
        Icon greenDiagonalWall = new ImageIcon(((new ImageIcon("Resources/Difficult/greenDiagonal.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH)); 
        Icon yellowDiagonalWall = new ImageIcon(((new ImageIcon("Resources/Difficult/yellowDiagonal.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH)); 
        
        boardSquares[0][5].setIcons(rightWall);
        boardSquares[0][5].setRightWall(true);
       
        boardSquares[0][6].setIcons(leftWall);
        boardSquares[0][6].setLeftWall(true);
    
        boardSquares[0][8].setIcons(rightWall);
        boardSquares[0][8].setRightWall(true);
   
        boardSquares[0][9].setIcons(leftWall);
        boardSquares[0][9].setLeftWall(true);
        
        boardSquares[1][4].setIcons(greenDiagonalWall);
        boardSquares[1][4].setDiagonalWall(true,"green");

        boardSquares[2][14].setIcons(blueDiagonalWall);
        boardSquares[2][14].setDiagonalWall(true,"blue");
        
        boardSquares[2][15].setIcons(bottomWall);
        boardSquares[2][15].setBottomWall(true);
     
        boardSquares[3][15].setIcons(topWall);
        boardSquares[3][15].setTopWall(true);
        
        boardSquares[5][0].setIcons(bottomWall);
        boardSquares[5][0].setBottomWall(true);
        
        boardSquares[6][0].setIcons(topWall);
        boardSquares[6][0].setTopWall(true);
        
        boardSquares[7][5].setIcons(yellowDiagonalWall);
        boardSquares[7][5].setDiagonalWall(true,"yellow");
        
        boardSquares[7][11].setIcons(redDiagonalWall);
        boardSquares[7][11].setDiagonalWall(true,"red");
        
        boardSquares[10][0].setIcons(bottomWall);
        boardSquares[10][0].setBottomWall(true);
        
        boardSquares[11][0].setIcons(topWall);
        boardSquares[11][0].setTopWall(true);
        
        boardSquares[12][6].setIcons(greenDiagonalWall);
        boardSquares[12][6].setDiagonalWall(true,"green");
        
        boardSquares[12][9].setIcons(yellowDiagonalWall);
        boardSquares[12][9].setDiagonalWall(true,"yellow");
        
        boardSquares[12][15].setIcons(bottomWall);
        boardSquares[12][15].setBottomWall(true);
        
        boardSquares[13][15].setIcons(topWall);
        boardSquares[13][15].setTopWall(true);
        
        boardSquares[13][1].setIcons(redDiagonalWall);
        boardSquares[13][1].setDiagonalWall(true,"red");
        
        boardSquares[14][11].setIcons(blueDiagonalWall);
        boardSquares[14][11].setDiagonalWall(true,"blue");
        
        boardSquares[15][6].setIcons(rightWall);
        boardSquares[15][6].setRightWall(true);
        
        boardSquares[15][7].setIcons(leftWall);
        boardSquares[15][7].setLeftWall(true);
        
        boardSquares[15][10].setIcons(rightWall);
        boardSquares[15][10].setRightWall(true);
        
        boardSquares[15][11].setIcons(leftWall);
        boardSquares[15][11].setLeftWall(true);
    }
    
    //same as previous method but color vision assisted
    public void makeColorVisionWalls()
    {
        Icon leftWall = new ImageIcon(((new ImageIcon("Resources/Assisted/leftWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon topWall = new ImageIcon(((new ImageIcon("Resources/Assisted/topWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon bottomWall = new ImageIcon(((new ImageIcon("Resources/Assisted/bottomWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon rightWall = new ImageIcon(((new ImageIcon("Resources/Assisted/rightWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon redDiagonalWall = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/redDiagonal.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH)); 
        Icon blueDiagonalWall = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/blueDiagonal.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH)); 
        Icon greenDiagonalWall = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/greenDiagonal.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH)); 
        Icon yellowDiagonalWall = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/yellowDiagonal.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH)); 
        
        boardSquares[0][5].setIcons(rightWall);
        boardSquares[0][5].setRightWall(true);
       
        boardSquares[0][6].setIcons(leftWall);
        boardSquares[0][6].setLeftWall(true);
    
        boardSquares[0][8].setIcons(rightWall);
        boardSquares[0][8].setRightWall(true);
   
        boardSquares[0][9].setIcons(leftWall);
        boardSquares[0][9].setLeftWall(true);
        
        boardSquares[1][4].setIcons(greenDiagonalWall);
        boardSquares[1][4].setDiagonalWall(true,"green");

        boardSquares[2][14].setIcons(blueDiagonalWall);
        boardSquares[2][14].setDiagonalWall(true,"blue");
        
        boardSquares[2][15].setIcons(bottomWall);
        boardSquares[2][15].setBottomWall(true);
     
        boardSquares[3][15].setIcons(topWall);
        boardSquares[3][15].setTopWall(true);
        
        boardSquares[5][0].setIcons(bottomWall);
        boardSquares[5][0].setBottomWall(true);
        
        boardSquares[6][0].setIcons(topWall);
        boardSquares[6][0].setTopWall(true);
        
        boardSquares[7][5].setIcons(yellowDiagonalWall);
        boardSquares[7][5].setDiagonalWall(true,"yellow");
        
        boardSquares[7][11].setIcons(redDiagonalWall);
        boardSquares[7][11].setDiagonalWall(true,"red");
        
        boardSquares[10][0].setIcons(bottomWall);
        boardSquares[10][0].setBottomWall(true);
        
        boardSquares[11][0].setIcons(topWall);
        boardSquares[11][0].setTopWall(true);
        
        boardSquares[12][6].setIcons(greenDiagonalWall);
        boardSquares[12][6].setDiagonalWall(true,"green");
        
        boardSquares[12][9].setIcons(yellowDiagonalWall);
        boardSquares[12][9].setDiagonalWall(true,"yellow");
        
        boardSquares[12][15].setIcons(bottomWall);
        boardSquares[12][15].setBottomWall(true);
        
        boardSquares[13][15].setIcons(topWall);
        boardSquares[13][15].setTopWall(true);
        
        boardSquares[13][1].setIcons(redDiagonalWall);
        boardSquares[13][1].setDiagonalWall(true,"red");
        
        boardSquares[14][11].setIcons(blueDiagonalWall);
        boardSquares[14][11].setDiagonalWall(true,"blue");
        
        boardSquares[15][6].setIcons(rightWall);
        boardSquares[15][6].setRightWall(true);
        
        boardSquares[15][7].setIcons(leftWall);
        boardSquares[15][7].setLeftWall(true);
        
        boardSquares[15][10].setIcons(rightWall);
        boardSquares[15][10].setRightWall(true);
        
        boardSquares[15][11].setIcons(leftWall);
        boardSquares[15][11].setLeftWall(true);
    }
    
    //making the special squares on the board
    public void makeSpecialSquares()
    {
        specials = new ArrayList<Square>();
        Icon leftWall = new ImageIcon(((new ImageIcon("Resources/leftWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon topWall = new ImageIcon(((new ImageIcon("Resources/topWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon bottomWall = new ImageIcon(((new ImageIcon("Resources/bottomWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon rightWall = new ImageIcon(((new ImageIcon("Resources/rightWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        
        Icon redCircle = new ImageIcon(((new ImageIcon("Resources/redCircle.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares[3][1].setIcons(redCircle);
        boardSquares[3][1].setTopWall(true);
        boardSquares[3][1].setLeftWall(true);
        boardSquares[2][1].setBottomWall(true);
        boardSquares[2][1].setIcons(bottomWall);
        boardSquares[3][0].setRightWall(true);
        boardSquares[3][0].setIcons(rightWall);
        boardSquares[3][1].setSpecialSquare("redCircle");
        specials.add(boardSquares[3][1]);
        
   
        Icon redSquare = new ImageIcon(((new ImageIcon("Resources/redSquare.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares[1][10].setIcons(redSquare);
        boardSquares[1][10].setTopWall(true);
        boardSquares[1][10].setLeftWall(true);
        boardSquares[0][10].setBottomWall(true);
        boardSquares[0][10].setIcons(bottomWall);
        boardSquares[1][9].setRightWall(true);
        boardSquares[1][9].setIcons(rightWall);
        boardSquares[1][10].setSpecialSquare("redSquare");
        specials.add(boardSquares[1][10]);
        
       
        Icon greenTriangle = new ImageIcon(((new ImageIcon("Resources/greenTriangle.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares[6][2].setIcons(greenTriangle);
        boardSquares[6][2].setTopWall(true);
        boardSquares[6][2].setRightWall(true);
        boardSquares[5][2].setBottomWall(true);
        boardSquares[5][2].setIcons(bottomWall);
        boardSquares[6][2].setSpecialSquare("greenTriangle");
        specials.add(boardSquares[6][2]);
        

        Icon blueTriangle = new ImageIcon(((new ImageIcon("Resources/blueTriangle.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares[4][8].setIcons(blueTriangle);
        boardSquares[4][8].setBottomWall(true);
        boardSquares[4][8].setRightWall(true);
        boardSquares[5][8].setTopWall(true);
        boardSquares[5][8].setIcons(topWall);
        boardSquares[4][9].setLeftWall(true);
        boardSquares[4][9].setIcons(leftWall);
        boardSquares[4][8].setSpecialSquare("blueTriangle");
        specials.add(boardSquares[4][8]);
        
 
        Icon yellowStar = new ImageIcon(((new ImageIcon("Resources/yellowStar.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[4][6].setIcons(yellowStar);
        boardSquares[4][6].setBottomWall(true);
        boardSquares[4][6].setRightWall(true);
        boardSquares[5][6].setTopWall(true);
        boardSquares[5][6].setIcons(topWall);
        boardSquares[4][7].setLeftWall(true);
        boardSquares[4][7].setIcons(leftWall);
        boardSquares[4][6].setSpecialSquare("yellowStar");
        specials.add(boardSquares[4][6]);
        

        Icon greenStar = new ImageIcon(((new ImageIcon("Resources/greenStar.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[5][13].setIcons(greenStar);
        boardSquares[5][13].setBottomWall(true);
        boardSquares[5][13].setLeftWall(true);
        boardSquares[5][12].setRightWall(true);
        boardSquares[5][12].setIcons(rightWall);
        boardSquares[5][13].setSpecialSquare("greenStar");
        specials.add(boardSquares[5][13]);
        

        Icon blueSquare = new ImageIcon(((new ImageIcon("Resources/blueSquare.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[6][3].setIcons(blueSquare);
        boardSquares[6][3].setBottomWall(true);
        boardSquares[6][3].setLeftWall(true);
        boardSquares[7][3].setTopWall(true);
        boardSquares[7][3].setIcons(topWall);
        boardSquares[6][3].setSpecialSquare("blueSquare");
        specials.add(boardSquares[6][3]);
        
        
        Icon yellowCircle = new ImageIcon(((new ImageIcon("Resources/yellowCircle.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));       
        boardSquares[6][13].setIcons(yellowCircle);
        boardSquares[6][13].setTopWall(true);
        boardSquares[6][13].setRightWall(true);
        boardSquares[6][14].setLeftWall(true);
        boardSquares[6][14].setIcons(leftWall);
        boardSquares[6][13].setSpecialSquare("yellowCircle");
        specials.add(boardSquares[6][13]);
        

        Icon multivortex = new ImageIcon(((new ImageIcon("Resources/multivortex.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[10][7].setIcons(multivortex);
        boardSquares[10][7].setTopWall(true);
        boardSquares[10][7].setRightWall(true);
        boardSquares[9][7].setBottomWall(true);
        boardSquares[9][7].setIcons(bottomWall);
        boardSquares[10][8].setLeftWall(true);
        boardSquares[10][8].setIcons(leftWall);
        boardSquares[10][7].setSpecialSquare("multivortex");
        specials.add(boardSquares[10][7]);
        

        Icon blueCircle = new ImageIcon(((new ImageIcon("Resources/Difficult/blueCircle.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[13][3].setIcons(blueCircle);
        boardSquares[13][3].setTopWall(true);
        boardSquares[13][3].setLeftWall(true);
        boardSquares[13][2].setRightWall(true);
        boardSquares[13][2].setIcons(rightWall);
        boardSquares[13][3].setSpecialSquare("blueCircle");
        specials.add(boardSquares[13][3]);
        
        
        Icon yellowSquare = new ImageIcon(((new ImageIcon("Resources/yellowSquare.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[9][10].setIcons(yellowSquare);
        boardSquares[9][10].setBottomWall(true);
        boardSquares[9][10].setRightWall(true);
        boardSquares[10][10].setTopWall(true);
        boardSquares[10][10].setIcons(topWall);
        boardSquares[9][11].setLeftWall(true);
        boardSquares[9][11].setIcons(leftWall);
        boardSquares[9][10].setSpecialSquare("yellowSquare");
        specials.add(boardSquares[9][10]);
        

        Icon greenSquare = new ImageIcon(((new ImageIcon("Resources/Difficult/greenSquare.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[12][3].setIcons(greenSquare);
        boardSquares[12][3].setBottomWall(true);
        boardSquares[12][3].setRightWall(true);
        boardSquares[12][4].setLeftWall(true);
        boardSquares[12][4].setIcons(leftWall);
        boardSquares[12][3].setSpecialSquare("greenSquare");
        specials.add(boardSquares[12][3]);
        
      
        Icon redTriangle = new ImageIcon(((new ImageIcon("Resources/redTriangle.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[11][12].setIcons(redTriangle);
        boardSquares[11][12].setTopWall(true);
        boardSquares[11][12].setRightWall(true);
        boardSquares[10][12].setBottomWall(true);
        boardSquares[10][12].setIcons(bottomWall);
        boardSquares[11][12].setSpecialSquare("redTriangle");
        specials.add(boardSquares[11][12]);
        

        Icon greenCircle = new ImageIcon(((new ImageIcon("Resources/greenCircle.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[11][13].setIcons(greenCircle);
        boardSquares[11][13].setBottomWall(true);
        boardSquares[11][13].setLeftWall(true);
        boardSquares[12][13].setTopWall(true);
        boardSquares[12][13].setIcons(topWall);
        boardSquares[11][13].setSpecialSquare("greenCircle");
        specials.add(boardSquares[11][13]);
        

        Icon redStar = new ImageIcon(((new ImageIcon("Resources/redStar.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[14][5].setIcons(redStar);
        boardSquares[14][5].setTopWall(true);
        boardSquares[14][5].setRightWall(true);
        boardSquares[13][5].setBottomWall(true);
        boardSquares[13][5].setIcons(bottomWall);
        boardSquares[14][6].setLeftWall(true);
        boardSquares[14][6].setIcons(leftWall);
        boardSquares[14][5].setSpecialSquare("redStar");
        specials.add(boardSquares[14][5]);
        
        
        Icon blueStar = new ImageIcon(((new ImageIcon("Resources/blueStar.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[13][9].setIcons(blueStar);
        boardSquares[13][9].setTopWall(true);
        boardSquares[13][9].setLeftWall(true);
        boardSquares[12][9].setBottomWall(true);
        boardSquares[13][8].setRightWall(true);
        boardSquares[13][8].setIcons(rightWall);
        boardSquares[13][9].setSpecialSquare("blueStar");
        specials.add(boardSquares[13][9]);


        Icon yellowTriangle = new ImageIcon(((new ImageIcon("Resources/Difficult/yellowTriangle.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[9][2].setIcons(yellowTriangle);
        boardSquares[9][2].setBottomWall(true);
        boardSquares[9][2].setLeftWall(true);
        boardSquares[10][2].setTopWall(true);
        boardSquares[10][2].setIcons(topWall);
        boardSquares[9][1].setRightWall(true);
        boardSquares[9][1].setIcons(rightWall);
        boardSquares[9][2].setSpecialSquare("yellowTriangle");
        specials.add(boardSquares[9][2]);
    }
    
    //same as above method but with color vision assistance
    public void makeColorVisionSpecialSquares()
    {
        specials = new ArrayList<Square>();
        Icon leftWall = new ImageIcon(((new ImageIcon("Resources/Assisted/leftWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon topWall = new ImageIcon(((new ImageIcon("Resources/Assisted/topWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon bottomWall = new ImageIcon(((new ImageIcon("Resources/Assisted/bottomWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon rightWall = new ImageIcon(((new ImageIcon("Resources/Assisted/rightWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        
        Icon redCircle = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/redCircle.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares[3][1].setIcons(redCircle);
        boardSquares[3][1].setTopWall(true);
        boardSquares[3][1].setLeftWall(true);
        boardSquares[2][1].setBottomWall(true);
        boardSquares[2][1].setIcons(bottomWall);
        boardSquares[3][0].setRightWall(true);
        boardSquares[3][0].setIcons(rightWall);
        boardSquares[3][1].setSpecialSquare("redCircle");
        specials.add(boardSquares[3][1]);
   
        Icon redSquare = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/redSquare.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares[1][10].setIcons(redSquare);
        boardSquares[1][10].setTopWall(true);
        boardSquares[1][10].setLeftWall(true);
        boardSquares[0][10].setBottomWall(true);
        boardSquares[0][10].setIcons(bottomWall);
        boardSquares[1][9].setRightWall(true);
        boardSquares[1][9].setIcons(rightWall);
        boardSquares[1][10].setSpecialSquare("redSquare");
        specials.add(boardSquares[1][10]);
        
       
        Icon greenTriangle = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/greenTriangle.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares[6][2].setIcons(greenTriangle);
        boardSquares[6][2].setTopWall(true);
        boardSquares[6][2].setRightWall(true);
        boardSquares[5][2].setBottomWall(true);
        boardSquares[5][2].setIcons(bottomWall);
        boardSquares[6][2].setSpecialSquare("greenTriangle");
        specials.add(boardSquares[6][2]);
        

        Icon blueTriangle = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/blueTriangle.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares[4][8].setIcons(blueTriangle);
        boardSquares[4][8].setBottomWall(true);
        boardSquares[4][8].setRightWall(true);
        boardSquares[5][8].setTopWall(true);
        boardSquares[5][8].setIcons(topWall);
        boardSquares[4][9].setLeftWall(true);
        boardSquares[4][9].setIcons(leftWall);
        boardSquares[4][8].setSpecialSquare("blueTriangle");
        specials.add(boardSquares[4][8]);
        
 
        Icon yellowStar = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/yellowStar.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[4][6].setIcons(yellowStar);
        boardSquares[4][6].setBottomWall(true);
        boardSquares[4][6].setRightWall(true);
        boardSquares[5][6].setTopWall(true);
        boardSquares[5][6].setIcons(topWall);
        boardSquares[4][7].setLeftWall(true);
        boardSquares[4][7].setIcons(leftWall);
        boardSquares[4][6].setSpecialSquare("yellowStar");
        specials.add(boardSquares[4][6]);
        

        Icon greenStar = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/greenStar.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[5][13].setIcons(greenStar);
        boardSquares[5][13].setBottomWall(true);
        boardSquares[5][13].setLeftWall(true);
        boardSquares[5][12].setRightWall(true);
        boardSquares[5][12].setIcons(rightWall);
        boardSquares[5][13].setSpecialSquare("greenStar");
        specials.add(boardSquares[5][13]);
        

        Icon blueSquare = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/blueSquare.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[6][3].setIcons(blueSquare);
        boardSquares[6][3].setBottomWall(true);
        boardSquares[6][3].setLeftWall(true);
        boardSquares[7][3].setTopWall(true);
        boardSquares[7][3].setIcons(topWall);
        boardSquares[6][3].setSpecialSquare("blueSquare");
        specials.add(boardSquares[6][3]);
        
        
        Icon yellowCircle = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/yellowCircle.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));       
        boardSquares[6][13].setIcons(yellowCircle);
        boardSquares[6][13].setTopWall(true);
        boardSquares[6][13].setRightWall(true);
        boardSquares[6][14].setLeftWall(true);
        boardSquares[6][14].setIcons(leftWall);
        boardSquares[6][13].setSpecialSquare("yellowCircle");
        specials.add(boardSquares[6][13]);
        

        Icon multivortex = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/multivortex.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[10][7].setIcons(multivortex);
        boardSquares[10][7].setTopWall(true);
        boardSquares[10][7].setRightWall(true);
        boardSquares[9][7].setBottomWall(true);
        boardSquares[9][7].setIcons(bottomWall);
        boardSquares[10][8].setLeftWall(true);
        boardSquares[10][8].setIcons(leftWall);
        boardSquares[10][7].setSpecialSquare("multivortex");
        specials.add(boardSquares[10][7]);
        

        Icon blueCircle = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/blueCircle.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[13][3].setIcons(blueCircle);
        boardSquares[13][3].setTopWall(true);
        boardSquares[13][3].setLeftWall(true);
        boardSquares[13][2].setRightWall(true);
        boardSquares[13][2].setIcons(rightWall);
        boardSquares[13][3].setSpecialSquare("blueCircle");
        specials.add(boardSquares[13][3]);
        
        
        Icon yellowSquare = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/yellowSquare.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[9][10].setIcons(yellowSquare);
        boardSquares[9][10].setBottomWall(true);
        boardSquares[9][10].setRightWall(true);
        boardSquares[10][10].setTopWall(true);
        boardSquares[10][10].setIcons(topWall);
        boardSquares[9][11].setLeftWall(true);
        boardSquares[9][11].setIcons(leftWall);
        boardSquares[9][10].setSpecialSquare("yellowSquare");
        specials.add(boardSquares[9][10]);
        

        Icon greenSquare = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/greenSquare.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[12][3].setIcons(greenSquare);
        boardSquares[12][3].setBottomWall(true);
        boardSquares[12][3].setRightWall(true);
        boardSquares[12][4].setLeftWall(true);
        boardSquares[12][4].setIcons(leftWall);
        boardSquares[12][3].setSpecialSquare("greenSquare");
        specials.add(boardSquares[12][3]);
        
      
        Icon redTriangle = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/redTriangle.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[11][12].setIcons(redTriangle);
        boardSquares[11][12].setTopWall(true);
        boardSquares[11][12].setRightWall(true);
        boardSquares[10][12].setBottomWall(true);
        boardSquares[10][12].setIcons(bottomWall);
        boardSquares[11][12].setSpecialSquare("redTriangle");
        specials.add(boardSquares[11][12]);
        

        Icon greenCircle = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/greenCircle.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[11][13].setIcons(greenCircle);
        boardSquares[11][13].setBottomWall(true);
        boardSquares[11][13].setLeftWall(true);
        boardSquares[12][13].setTopWall(true);
        boardSquares[12][13].setIcons(topWall);
        boardSquares[11][13].setSpecialSquare("greenCircle");
        specials.add(boardSquares[11][13]);
        

        Icon redStar = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/redStar.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[14][5].setIcons(redStar);
        boardSquares[14][5].setTopWall(true);
        boardSquares[14][5].setRightWall(true);
        boardSquares[13][5].setBottomWall(true);
        boardSquares[13][5].setIcons(bottomWall);
        boardSquares[14][6].setLeftWall(true);
        boardSquares[14][6].setIcons(leftWall);
        boardSquares[14][5].setSpecialSquare("redStar");
        specials.add(boardSquares[14][5]);
        
        
        Icon blueStar = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/blueStar.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[13][9].setIcons(blueStar);
        boardSquares[13][9].setTopWall(true);
        boardSquares[13][9].setLeftWall(true);
        boardSquares[12][9].setBottomWall(true);
        boardSquares[13][8].setRightWall(true);
        boardSquares[13][8].setIcons(rightWall);
        boardSquares[13][9].setSpecialSquare("blueStar");
        specials.add(boardSquares[13][9]);


        Icon yellowTriangle = new ImageIcon(((new ImageIcon("Resources/AssistedDifficult/yellowTriangle.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[9][2].setIcons(yellowTriangle);
        boardSquares[9][2].setBottomWall(true);
        boardSquares[9][2].setLeftWall(true);
        boardSquares[10][2].setTopWall(true);
        boardSquares[10][2].setIcons(topWall);
        boardSquares[9][1].setRightWall(true);
        boardSquares[9][1].setIcons(rightWall);
        boardSquares[9][2].setSpecialSquare("yellowTriangle");
        specials.add(boardSquares[9][2]);
    }
    
    //sets the edges of the map as walls so the robots dont "fall off"
    public void setMapEdgeWall()
    {
        for(int column = 0; column < 16; column++)
        {
            boardSquares[column][0].setLeftWall(true);
        }
        
        for(int column = 0; column < 16; column++)
        {
            boardSquares[column][15].setRightWall(true);
        }
        
        for(int row = 0; row < 16; row++)
        {
            boardSquares[0][row].setTopWall(true);
        }
        
        for(int row = 0; row < 16; row++)
        {
            boardSquares[15][row].setBottomWall(true);
        }
    }
    
    //sets walls in the middle of the map so the robots dont go in it. This code 
    // be edited to show the special square the robots will need to go to
    public void makeMiddleSquares()
    {
        Icon black = new ImageIcon(((new ImageIcon("Resources/black.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        
        boardSquares[7][7].setIcons(black);
        boardSquares[7][7].setTopWall(true);
        boardSquares[7][7].setLeftWall(true);
        boardSquares[7][7].setBottomWall(true);
        boardSquares[7][7].setRightWall(true);
        boardSquares[6][7].setBottomWall(true);
        boardSquares[7][6].setRightWall(true);
        
        boardSquares[7][8].setIcons(black);
        boardSquares[7][8].setTopWall(true);
        boardSquares[7][8].setLeftWall(true);
        boardSquares[7][8].setBottomWall(true);
        boardSquares[7][8].setRightWall(true);
        boardSquares[6][8].setBottomWall(true);
        boardSquares[7][9].setLeftWall(true);
        
        boardSquares[8][7].setIcons(black);
        boardSquares[8][7].setTopWall(true);
        boardSquares[8][7].setLeftWall(true);
        boardSquares[8][7].setBottomWall(true);
        boardSquares[8][7].setRightWall(true);
        boardSquares[8][6].setRightWall(true);
        boardSquares[9][7].setTopWall(true);
        
        boardSquares[8][8].setIcons(black);
        boardSquares[8][8].setTopWall(true);
        boardSquares[8][8].setLeftWall(true);
        boardSquares[8][8].setBottomWall(true);
        boardSquares[8][8].setRightWall(true);
        boardSquares[9][8].setTopWall(true);
        boardSquares[8][9].setLeftWall(true);
    }
    
    //sets the robots on the board in a random space
    public void setRobot()
    {       
        ImageIcon red = new ImageIcon(((new ImageIcon("Resources/redRobot.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        ImageIcon yellow = new ImageIcon(((new ImageIcon("Resources/yellowRobot.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        ImageIcon blue = new ImageIcon(((new ImageIcon("Resources/blueRobot.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        ImageIcon green = new ImageIcon(((new ImageIcon("Resources/greenRobot.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        
        redRobot = new Robot(red);
        blueRobot = new Robot(blue);
        yellowRobot = new Robot(yellow);
        greenRobot = new Robot(green);
        
        redRobot.setColor("red");
        blueRobot.setColor("blue");
        yellowRobot.setColor("yellow");
        greenRobot.setColor("green");
        
        int x = redRobot.getXCoord();
        int y = redRobot.getYCoord();
        rx = x;
        ry = y;
        Icon tempIcon = redRobot.getIcon();
        boardSquares[x][y].setIcons(tempIcon);
        boardSquares[x][y].setBackground(Color.RED);
        boardSquares[x][y].changeOccupied();
        
        x = yellowRobot.getXCoord();
        y = yellowRobot.getYCoord();
        yx = x;
        yy = y;
        tempIcon = yellowRobot.getIcon();
        boardSquares[x][y].setIcons(tempIcon);
        boardSquares[x][y].setBackground(Color.YELLOW);
        boardSquares[x][y].changeOccupied();
        
        x = greenRobot.getXCoord();
        y = greenRobot.getYCoord();
        gx = x;
        gy = y;
        tempIcon = greenRobot.getIcon();
        boardSquares[x][y].setIcons(tempIcon);
        boardSquares[x][y].setBackground(Color.GREEN);
        boardSquares[x][y].changeOccupied();
        
        x = blueRobot.getXCoord();
        y = blueRobot.getYCoord();
        bx = x;
        by = y;
        tempIcon = blueRobot.getIcon();
        boardSquares[x][y].setIcons(tempIcon);
        boardSquares[x][y].setBackground(Color.BLUE);
        boardSquares[x][y].changeOccupied();
    }
    
    //same as previous method but with color vision support
    public void setColorVisionRobot()
    {       
        ImageIcon red = new ImageIcon(((new ImageIcon("Resources/Assisted/redRobot.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        ImageIcon yellow = new ImageIcon(((new ImageIcon("Resources/Assisted/yellowRobot.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        ImageIcon blue = new ImageIcon(((new ImageIcon("Resources/Assisted/blueRobot.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        ImageIcon green = new ImageIcon(((new ImageIcon("Resources/Assisted/greenRobot.png"))
        .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        
        redRobot = new Robot(red);
        blueRobot = new Robot(blue);
        yellowRobot = new Robot(yellow);
        greenRobot = new Robot(green);
        
        redRobot.setColor("red");
        blueRobot.setColor("blue");
        yellowRobot.setColor("yellow");
        greenRobot.setColor("green");
        
        int x = redRobot.getXCoord();
        int y = redRobot.getYCoord();
        rx = x;
        ry = y;
        Icon tempIcon = redRobot.getIcon();
        boardSquares[x][y].setIcons(tempIcon);
        boardSquares[x][y].setBackground(Color.GRAY);
        boardSquares[x][y].changeOccupied();
        
        x = yellowRobot.getXCoord();
        y = yellowRobot.getYCoord();
        yx = x;
        yy = y;
        tempIcon = yellowRobot.getIcon();
        boardSquares[x][y].setIcons(tempIcon);
        boardSquares[x][y].setBackground(Color.GRAY);
        boardSquares[x][y].changeOccupied();
        
        x = greenRobot.getXCoord();
        y = greenRobot.getYCoord();
        gx = x;
        gy = y;
        tempIcon = greenRobot.getIcon();
        boardSquares[x][y].setIcons(tempIcon);
        boardSquares[x][y].setBackground(Color.GRAY);
        boardSquares[x][y].changeOccupied();
        
        x = blueRobot.getXCoord();
        y = blueRobot.getYCoord();
        bx = x;
        by = y;
        tempIcon = blueRobot.getIcon();
        boardSquares[x][y].setIcons(tempIcon);
        boardSquares[x][y].setBackground(Color.GRAY);
        boardSquares[x][y].changeOccupied();
    }
    
    // place all robots in initial round position for next player
    public void resetRobots()
    {
        
    }
    
    //a mathod to change the icon on a given square on the board
    //This is mainly used to move the robot from on block to another by
    //replacing the image of the square on the board with that of the robot
    public static void changeIcon(int x, int y, Icon icon)
    {
        boardSquares[x][y].setIcons(icon);
        boardSquares[x][y].setIcon(icon);
    }
    
    //returns a particular square in the board
    public static Square getSquare(int x, int y)
    {
        return boardSquares[x][y];
    }
    
    public void changeSelectedRobotLabel(String color)
    {
        if(color.equals("none"))
        selectedRobot.setText("Robot selected: NONE");
        
        if(color.equals("red"))
        selectedRobot.setText("Robot selected: RED");
        
        if(color.equals("blue"))
        selectedRobot.setText("Robot selected: BLUE");
        
        if(color.equals("yellow"))
        selectedRobot.setText("Robot selected: YELLOW");
        
        if(color.equals("green"))
        selectedRobot.setText("Robot selected: GREEN");
    }
    
    //changes the player text to show who the current player is
    public void changeCurrPlayer(String player)
    {
        currPlayer.setText("Player: " + player);
    }
    
    //create players objects and store in array
    public void createPlayers()
    {
        for(int i = 0; i<num_of_players; i++)
        {
            int x = i + 1;
            String name = "Player " + x;
            players[i] = new Player(name);
        }
        LastPlayer = players[num_of_players-1];
    }
    
     //change the player score of a given int player
    public void changePlayerScore(int score, int player)
    {
        if(player == 1)
            player1.setText("Player 1: " + score);
            
        if(player == 2)
            player2.setText("Player 2: " + score);
            
        if(player == 3)
            player3.setText("Player 3: " + score);
            
        if(player == 4)
            player4.setText("Player 4: " + score);
    }
    
    //changes the moves text to show the total number of moves made by the current player
    public void changeMoves(int totalMoves)
    {
        moves.setText("Moves: " + totalMoves);
    }   
    
    //return a list of all special squares
    public ArrayList<Square> getSpecialSquares()
    {
        return specials;
    }
    
    //reset all player moves to 0
    public void resetPlayers()
    {
        for (int i = 0; i < num_of_players; i++)
        {
            players[i].moveReset();
        }
    }
    
    //change player turn
    public void changePlayer()
    {
        totalMoves = 0;
        changeMoves(totalMoves);
        resetRobots();
        if (currentPlayer == null || currentPlayer == LastPlayer)
        {
            currentPlayer = players[0];
            changeCurrPlayer(currentPlayer.getName());
        }
        else if(currentPlayer.getName().equals("Player 1"))
        {
            currentPlayer = players[1];
            changeCurrPlayer(currentPlayer.getName());
        }
        else if(currentPlayer.getName().equals("Player 2"))
        {
            currentPlayer = players[2];
            changeCurrPlayer(currentPlayer.getName());
        }
        else if(currentPlayer.getName().equals("Player 3"))
        {
            currentPlayer = players[3];
            changeCurrPlayer(currentPlayer.getName());
        }
        else{noWinner();}
    }
    
    //display that round has no winner
    public void noWinner()
    {
        
    }
    
    //creates a new goal for players to reach
    public void newGoal()
    {
        int x = (int)(Math.random()*getSpecialSquares().size());
        setGoal(x);
        //changeGoal(getSpecialSquares().get(x).getSpecialSquare());
        setObjective(getSpecialSquares().get(x).getSpecialSquare());
    }
    
    // set special square at int x of specials to be current game goal
    public void setGoal(int x)
    {
        getSpecialSquares().get(x).setIsGoal();
        Goal = getSpecialSquares().get(x);
    }
    
    public Square getGoal()
    {
        return Goal;
    }
    

    
    public void setObjective(String objective)
    {
        if(!MainMenu.isColorVision())
        {
            for(int i=1; i<=4; i++)
            {
                ImageIcon obj = new ImageIcon(((new ImageIcon("Resources/Middle/" + objective + i + ".png"))
                .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
                
                if(i==1)
                boardSquares[7][7].setIcons(obj);
                
                if(i==2)
                boardSquares[7][8].setIcons(obj);
                
                if(i==3)
                boardSquares[8][7].setIcons(obj);
                
                if(i==4)
                boardSquares[8][8].setIcons(obj);
            }
       }
       else
       {
           for(int i=1; i<=4; i++)
            {
                ImageIcon obj = new ImageIcon(((new ImageIcon("Resources/MiddleAssisted/" + objective + i + ".png"))
                .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
                
                if(i==1)
                boardSquares[7][7].setIcons(obj);
                
                if(i==2)
                boardSquares[7][8].setIcons(obj);
                
                if(i==3)
                boardSquares[8][7].setIcons(obj);
                
                if(i==4)
                boardSquares[8][8].setIcons(obj);
            }
       }
    }
    
    //check if current player has reached the goal
    public void goalReached(int x,int y,String color)
    {
        int gX = Goal.getXCoord();
        int gY = Goal.getYCoord();
        // for(int i = 0; i < getSpecialSquares().size(); i++)
        // {
            
        // }
        if((Goal.getSpecialSquare().contains(color)|| 
        Goal.getSpecialSquare().equals("multivortex")) && gX==x && gY==y)
        {
            currentPlayer.move(totalMoves);
            nextPlayer();
        }
    }
    
    //check round end 
    public void nextPlayer()
    {
        if(currentPlayer == LastPlayer)
        {
            setWinner();
        }
        else{changePlayer();}
    }
    
    //sets the winner of the round
    public void setWinner()
    {
        int lowest = maxMoves;
        for (int i =0; i < num_of_players; i ++)
        {
            if(players[i].getMoves()<lowest)
            {
                lowest = players[i].getMoves();
                roundWinner = players[i];
            }
        }
        roundWinner.setScore();
        setScores();
    }
    
    //changes the score values of all players if there are any changes
    public void setScores()
    {
        for(int i = 0; i < num_of_players; i ++)
        {
            changePlayerScore(players[i].getScore(), i+1);
        }
        gameOver();
    }
    
    //display the results of the game and indicates the winner 
    //then return to main menu
    public void gameOver()
    {
        
    }
    
    public void actionPerformed(ActionEvent aevt)
    {
        
    }
    
    
    public void mouseClicked(MouseEvent mevt)
    {
        Object selected = mevt.getSource();

        if(selected instanceof Square)
        {
            Square square = ((Square) selected);
            int x = square.getXCoord();
            int y = square.getYCoord();
            if ((x == redRobot.getXCoord() && y == redRobot.getYCoord())
            && (!blueRobot.isSelected() && !greenRobot.isSelected()
            && !yellowRobot.isSelected()))
            {
                redRobot.changeSelected();
                if (redRobot.isSelected())
                    changeSelectedRobotLabel("red");
                else
                    changeSelectedRobotLabel("none");
            }
            
            if (redRobot.isSelected() && (x == redRobot.getXCoord() ||
            y == redRobot.getYCoord()) && !(x ==redRobot.getXCoord() &&
            y == redRobot.getYCoord()))
            {
                redRobot.diffMove(x,y);totalMoves++;
                changeMoves(totalMoves);
                goalReached(redRobot.getXCoord(),redRobot.getYCoord(),"red");
            }
            
            if ((x == blueRobot.getXCoord() && y == blueRobot.getYCoord())
            && (!redRobot.isSelected() && !greenRobot.isSelected()
            && !yellowRobot.isSelected()))
            {
                blueRobot.changeSelected();
                if (blueRobot.isSelected())
                    changeSelectedRobotLabel("blue");
                else
                    changeSelectedRobotLabel("none");
            }
            
            if ((x == yellowRobot.getXCoord() && y == yellowRobot.getYCoord())
            && (!blueRobot.isSelected() && !greenRobot.isSelected()
            && !redRobot.isSelected()))
            {
                yellowRobot.changeSelected();
                if (yellowRobot.isSelected())
                    changeSelectedRobotLabel("yellow");
                else
                    changeSelectedRobotLabel("none");
            }
            
            if ((x == greenRobot.getXCoord() && y == greenRobot.getYCoord())
            && (!blueRobot.isSelected() && !redRobot.isSelected()
            && !yellowRobot.isSelected()))
            {
                greenRobot.changeSelected();
                if (greenRobot.isSelected())
                    changeSelectedRobotLabel("green");
                else
                    changeSelectedRobotLabel("none");
            }
            
            if (blueRobot.isSelected() && (x == blueRobot.getXCoord() ||
            y == blueRobot.getYCoord()) && !(x ==blueRobot.getXCoord() &&
            y == blueRobot.getYCoord()))
            {
                blueRobot.diffMove(x,y);
                totalMoves++;
                changeMoves(totalMoves);
                goalReached(blueRobot.getXCoord(),blueRobot.getYCoord(),"blue");
            }
            
            if (greenRobot.isSelected() && (x == greenRobot.getXCoord() ||
            y == greenRobot.getYCoord()) && !(x ==greenRobot.getXCoord() &&
            y == greenRobot.getYCoord()))
            {
                greenRobot.diffMove(x,y);
                totalMoves++;
                changeMoves(totalMoves);
                goalReached(greenRobot.getXCoord(),greenRobot.getYCoord(),"green");
            }
            
            if (yellowRobot.isSelected() && (x == yellowRobot.getXCoord() ||
            y == yellowRobot.getYCoord()) && !(x ==yellowRobot.getXCoord() &&
            y == yellowRobot.getYCoord()))
            {
                yellowRobot.diffMove(x,y);
                totalMoves++;
                changeMoves(totalMoves);
                goalReached(yellowRobot.getXCoord(),yellowRobot.getYCoord(),"yellow");
            }
        }
    }
    
    public void mouseEntered(MouseEvent arg0){}
    public void mouseExited(MouseEvent arg0){}
    public void mousePressed(MouseEvent arg0){}
    public void mouseReleased(MouseEvent arg0){}

}
