import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.Color;
import java.util.*;

/**
 * Creates a simple board that can be either normal or color vision assisted
 *
 * @author (Mohammad Hasan 201858685, Jabulani Mabena 201820578)
 *
 */
public class EasyMap extends JFrame implements ActionListener, MouseListener
{
    private JPanel west;
    private JPanel east;
    private static Square[][] boardSquares;
    private Robot redRobot;
    private Robot blueRobot;
    private Robot greenRobot;
    private Robot yellowRobot;
    private JLabel selectedRobot;
    private JLabel currPlayer;
    private JLabel moves;
    private int num_of_players;
    private JLabel player1;
    private JLabel player2;
    private JLabel player3;
    private JLabel player4;
    private JLabel goal;
    private Square Goal;
    private int rx,ry,gx,gy,bx,by,yx,yy;
    private int totalMoves;
    private JLabel p1Score,p2Score,p3Score,p4Score;
    private JLabel p1Moves,p2Moves,p3Moves,p4Moves;
    private ArrayList<Square> specials;
    private Player players[];
    private Player currentPlayer;
    private Player lastPlayer;
    private Player roundWinner;
    private Player winner;
    private int maxMoves = 30;

    public EasyMap(int num_of_players)
    {
        super("Ricochet Robots Easy");

        this.num_of_players = num_of_players;
        totalMoves = 0;
        players = new Player[num_of_players];
        createPlayers();
        //Panel where the board will be placed
        west = new JPanel();
        east = new JPanel();

        west.setLayout(new GridLayout(16,16));
        east.setLayout(new GridLayout(0,1));

        //if color vision support is selected then show the color vision supported board or else show board with normal colors
        if(!MainMenu.isColorVision())
        {
            makeBoard(); makeRightPanel(); makeWalls(); makeSpecialSquares(); setMapEdgeWall(); 
            makeMiddleSquares(); newRound();
        }
        else
        {
            makeColorVisionBoard(); makeRightPanel(); makeColorVisionWalls(); makeColorVisionSpecialSquares(); setMapEdgeWall(); 
            makeMiddleSquares(); newColorRound();
        }

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(west, BorderLayout.WEST);
        getContentPane().add(east, BorderLayout.EAST);

        setPreferredSize(new Dimension(850, 750));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true); 
    }

    // makes board with normal colors
    public void makeBoard()
    {
        Icon basicSquare = new ImageIcon(((new ImageIcon("Resources/basicSquare.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares = new Square[16][16];
        for(int column = 0; column <16; column++)
        {
            for(int row=0; row <16; row++)
            {
                boardSquares[column][row] = new Square();
                boardSquares[column][row].setX(column);
                boardSquares[column][row].setY(row);
                boardSquares[column][row].setIcon(basicSquare);
                boardSquares[column][row].setSpecialSquare(null);
                boardSquares[column][row].setSize(50,50);
                boardSquares[column][row].setIcons(basicSquare);               
                boardSquares[column][row].setOpaque(true);
                boardSquares[column][row].addActionListener(this);
                boardSquares[column][row].addMouseListener(this);
                boardSquares[column][row].setBorderPainted(false);
                boardSquares[column][row].setBorder(BorderFactory.createEmptyBorder());
                boardSquares[column][row].setBackground(Color.GRAY); 
                west.add(boardSquares[column][row]);
            }
        }
    }

    // makes color vision assisted board
    public void makeColorVisionBoard()
    {
        Icon basicSquare = new ImageIcon(((new ImageIcon("Resources/Assisted/basicSquare.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares = new Square[16][16];
        for(int column = 0; column <16; column++)
        {
            for(int row=0; row <16; row++)
            {
                boardSquares[column][row] = new Square();
                boardSquares[column][row].setX(column);
                boardSquares[column][row].setY(row);
                boardSquares[column][row].setSpecialSquare(null);
                boardSquares[column][row].setIcon(basicSquare);
                boardSquares[column][row].setSize(50,50);
                boardSquares[column][row].setIcons(basicSquare);               
                boardSquares[column][row].setOpaque(true);
                boardSquares[column][row].addActionListener(this);
                boardSquares[column][row].addMouseListener(this);
                boardSquares[column][row].setBorderPainted(false);
                boardSquares[column][row].setBorder(BorderFactory.createEmptyBorder());
                boardSquares[column][row].setBackground(Color.GRAY); 
                west.add(boardSquares[column][row]);
            }
        }
    }

    public void makeRightPanel()
    {
        currPlayer = new JLabel("Current Player: None");
        selectedRobot = new JLabel("Robot selected: None");
        moves = new JLabel("Moves: 0");
        goal = new JLabel("Goal: ");

        if(num_of_players == 1)
        {
            player1 = new JLabel("Player 1: ");
            p1Score = new JLabel("Score: 0");
            p1Moves = new JLabel("Moves: 0");
            east.add(player1);
            east.add(p1Score);
            east.add(p1Moves);
        }

        if(num_of_players == 2)
        {
            player1 = new JLabel("Player 1: ");
            // p1Score = new JLabel("Score: 0");
            // p1Moves = new JLabel("Moves: 0");
            player2 = new JLabel("Player 2: ");
            // p1Score = new JLabel("Score: 0");
            // p1Moves = new JLabel("Moves: 0");
            east.add(player1);
            // east.add(p1Score);
            // east.add(p1Moves);
            east.add(player2);
            // east.add(p2Score);
            // east.add(p2Moves);
        }

        if(num_of_players == 3)
        {
            player1 = new JLabel("Player 1: ");
            // p1Score = new JLabel("Score: 0");
            // p1Moves = new JLabel("Moves: 0");
            player2 = new JLabel("Player 2: ");
            // p1Score = new JLabel("Score: 0");
            // p1Moves = new JLabel("Moves: 0");
            player3 = new JLabel("Player 3: ");
            // p1Score = new JLabel("Score: 0");
            // p1Moves = new JLabel("Moves: 0");
            east.add(player1);
            // east.add(p1Score);
            // east.add(p1Moves);
            east.add(player2);
            // east.add(p2Score);
            // east.add(p2Moves);
            east.add(player3);
            // east.add(p3Score);
            // east.add(p3Moves);
        }

        if(num_of_players == 4)
        {
            player1 = new JLabel("Player 1: ");
            // p1Score = new JLabel("Score: 0");
            // p1Moves = new JLabel("Moves: 0");
            player2 = new JLabel("Player 2: ");
            // p1Score = new JLabel("Score: 0");
            // p1Moves = new JLabel("Moves: 0");
            player3 = new JLabel("Player 3: ");
            // p1Score = new JLabel("Score: 0");
            // p1Moves = new JLabel("Moves: 0");
            player4 = new JLabel("Player 4: ");
            // p1Score = new JLabel("Score: 0");
            // p1Moves = new JLabel("Moves: 0");
            east.add(player1);
            // east.add(p1Score);
            // east.add(p1Moves);
            east.add(player2);
            // east.add(p2Score);
            // east.add(p2Moves);
            east.add(player3);
            // east.add(p3Score);
            // east.add(p3Moves);
            east.add(player4);
            // east.add(p4Score);
            // east.add(p4Moves);
        }

        east.add(currPlayer);
        east.add(goal);
        east.add(moves);
        east.add(selectedRobot);
    }

    //making specific spaces have the charectaristics of a wall
    public void makeWalls()
    {
        Icon leftWall = new ImageIcon(((new ImageIcon("Resources/leftWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon topWall = new ImageIcon(((new ImageIcon("Resources/topWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon bottomWall = new ImageIcon(((new ImageIcon("Resources/bottomWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon rightWall = new ImageIcon(((new ImageIcon("Resources/rightWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));

        boardSquares[10][15].setIcons(bottomWall);
        boardSquares[10][15].setBottomWall(true);

        boardSquares[3][15].setIcons(bottomWall);
        boardSquares[3][15].setBottomWall(true);

        boardSquares[4][15].setIcons(topWall);
        boardSquares[4][15].setTopWall(true);

        boardSquares[0][1].setIcons(rightWall);
        boardSquares[0][1].setRightWall(true);

        boardSquares[15][6].setIcons(rightWall);
        boardSquares[15][6].setRightWall(true);

        boardSquares[15][7].setIcons(leftWall);
        boardSquares[15][7].setLeftWall(true);

        boardSquares[15][11].setIcons(rightWall);
        boardSquares[15][11].setRightWall(true);

        boardSquares[15][12].setIcons(leftWall);
        boardSquares[15][12].setLeftWall(true);

        boardSquares[11][15].setIcons(topWall);
        boardSquares[11][15].setTopWall(true);

        boardSquares[0][2].setIcons(leftWall);
        boardSquares[0][2].setLeftWall(true);

        boardSquares[0][11].setIcons(rightWall);
        boardSquares[0][11].setRightWall(true);

        boardSquares[0][12].setIcons(leftWall);
        boardSquares[0][12].setLeftWall(true);

        boardSquares[6][0].setIcons(topWall);
        boardSquares[6][0].setTopWall(true);

        boardSquares[5][0].setIcons(bottomWall);
        boardSquares[5][0].setBottomWall(true);

        boardSquares[12][0].setIcons(topWall);
        boardSquares[12][0].setTopWall(true);

        boardSquares[11][0].setIcons(bottomWall);
        boardSquares[11][0].setBottomWall(true);
    }

    //same as previous method but color vision assisted
    public void makeColorVisionWalls()
    {
        Icon leftWall = new ImageIcon(((new ImageIcon("Resources/Assisted/leftWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon topWall = new ImageIcon(((new ImageIcon("Resources/Assisted/topWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon bottomWall = new ImageIcon(((new ImageIcon("Resources/Assisted/bottomWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon rightWall = new ImageIcon(((new ImageIcon("Resources/Assisted/rightWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));

        boardSquares[10][15].setIcons(bottomWall);
        boardSquares[10][15].setBottomWall(true);

        boardSquares[3][15].setIcons(bottomWall);
        boardSquares[3][15].setBottomWall(true);

        boardSquares[4][15].setIcons(topWall);
        boardSquares[4][15].setTopWall(true);

        boardSquares[0][1].setIcons(rightWall);
        boardSquares[0][1].setRightWall(true);

        boardSquares[15][6].setIcons(rightWall);
        boardSquares[15][6].setRightWall(true);

        boardSquares[15][7].setIcons(leftWall);
        boardSquares[15][7].setLeftWall(true);

        boardSquares[15][11].setIcons(rightWall);
        boardSquares[15][11].setRightWall(true);

        boardSquares[15][12].setIcons(leftWall);
        boardSquares[15][12].setLeftWall(true);

        boardSquares[11][15].setIcons(topWall);
        boardSquares[11][15].setTopWall(true);

        boardSquares[0][2].setIcons(leftWall);
        boardSquares[0][2].setLeftWall(true);

        boardSquares[0][11].setIcons(rightWall);
        boardSquares[0][11].setRightWall(true);

        boardSquares[0][12].setIcons(leftWall);
        boardSquares[0][12].setLeftWall(true);

        boardSquares[6][0].setIcons(topWall);
        boardSquares[6][0].setTopWall(true);

        boardSquares[5][0].setIcons(bottomWall);
        boardSquares[5][0].setBottomWall(true);

        boardSquares[12][0].setIcons(topWall);
        boardSquares[12][0].setTopWall(true);

        boardSquares[11][0].setIcons(bottomWall);
        boardSquares[11][0].setBottomWall(true);
    }

    //making the special squares on the board
    public void makeSpecialSquares()
    {
        specials = new ArrayList<Square>();
        Icon leftWall = new ImageIcon(((new ImageIcon("Resources/leftWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon topWall = new ImageIcon(((new ImageIcon("Resources/topWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon bottomWall = new ImageIcon(((new ImageIcon("Resources/bottomWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon rightWall = new ImageIcon(((new ImageIcon("Resources/rightWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));

        Icon redCircle = new ImageIcon(((new ImageIcon("Resources/redCircle.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares[1][4].setIcons(redCircle);
        boardSquares[1][4].setTopWall(true);
        boardSquares[1][4].setLeftWall(true);
        boardSquares[0][4].setBottomWall(true);
        boardSquares[0][4].setIcons(bottomWall);
        boardSquares[1][3].setRightWall(true);
        boardSquares[1][3].setIcons(rightWall);
        boardSquares[1][4].setSpecialSquare("redCircle");
        specials.add(boardSquares[1][4]);

        Icon redSquare = new ImageIcon(((new ImageIcon("Resources/redSquare.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares[1][13].setIcons(redSquare);
        boardSquares[1][13].setTopWall(true);
        boardSquares[1][13].setLeftWall(true);
        boardSquares[0][13].setBottomWall(true);
        boardSquares[0][13].setIcons(bottomWall);
        boardSquares[1][12].setRightWall(true);
        boardSquares[1][12].setIcons(rightWall);
        boardSquares[1][13].setSpecialSquare("redSquare");
        specials.add(boardSquares[1][13]);

        Icon greenTriangle = new ImageIcon(((new ImageIcon("Resources/greenTriangle.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares[3][1].setIcons(greenTriangle);
        boardSquares[3][1].setTopWall(true);
        boardSquares[3][1].setRightWall(true);
        boardSquares[2][1].setBottomWall(true);
        boardSquares[2][1].setIcons(bottomWall);
        boardSquares[3][2].setLeftWall(true);
        boardSquares[3][2].setIcons(leftWall);
        boardSquares[3][1].setSpecialSquare("greenTriangle");
        specials.add(boardSquares[3][1]);

        Icon blueTriangle = new ImageIcon(((new ImageIcon("Resources/blueTriangle.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares[3][9].setIcons(blueTriangle);
        boardSquares[3][9].setBottomWall(true);
        boardSquares[3][9].setRightWall(true);
        boardSquares[4][9].setTopWall(true);
        boardSquares[4][9].setIcons(topWall);
        boardSquares[3][10].setLeftWall(true);
        boardSquares[3][10].setIcons(leftWall);
        boardSquares[3][9].setSpecialSquare("blueTriangle");
        specials.add(boardSquares[3][9]);

        Icon yellowStar = new ImageIcon(((new ImageIcon("Resources/yellowStar.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[4][6].setIcons(yellowStar);
        boardSquares[4][6].setBottomWall(true);
        boardSquares[4][6].setRightWall(true);
        boardSquares[5][6].setTopWall(true);
        boardSquares[5][6].setIcons(topWall);
        boardSquares[4][7].setLeftWall(true);
        boardSquares[4][7].setIcons(leftWall);
        boardSquares[4][6].setSpecialSquare("yellowStar");
        specials.add(boardSquares[4][6]);

        Icon greenStar = new ImageIcon(((new ImageIcon("Resources/greenStar.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[5][14].setIcons(greenStar);
        boardSquares[5][14].setBottomWall(true);
        boardSquares[5][14].setLeftWall(true);
        boardSquares[6][14].setTopWall(true);
        boardSquares[6][14].setIcons(topWall);
        boardSquares[5][13].setRightWall(true);
        boardSquares[5][13].setIcons(rightWall);
        boardSquares[5][14].setSpecialSquare("greenStar");
        specials.add(boardSquares[5][14]);

        Icon blueSquare = new ImageIcon(((new ImageIcon("Resources/blueSquare.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[6][3].setIcons(blueSquare);
        boardSquares[6][3].setBottomWall(true);
        boardSquares[6][3].setLeftWall(true);
        boardSquares[7][3].setTopWall(true);
        boardSquares[7][3].setIcons(topWall);
        boardSquares[6][2].setRightWall(true);
        boardSquares[6][2].setIcons(rightWall);
        boardSquares[6][3].setSpecialSquare("blueSquare");
        specials.add(boardSquares[6][3]);

        Icon yellowCircle = new ImageIcon(((new ImageIcon("Resources/yellowCircle.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));       
        boardSquares[6][11].setIcons(yellowCircle);
        boardSquares[6][11].setTopWall(true);
        boardSquares[6][11].setRightWall(true);
        boardSquares[5][11].setBottomWall(true);
        boardSquares[5][11].setIcons(bottomWall);
        boardSquares[6][12].setLeftWall(true);
        boardSquares[6][12].setIcons(leftWall);
        boardSquares[6][11].setSpecialSquare("yellowCircle");
        specials.add(boardSquares[6][11]);

        Icon multivortex = new ImageIcon(((new ImageIcon("Resources/multivortex.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[8][5].setIcons(multivortex);
        boardSquares[8][5].setTopWall(true);
        boardSquares[8][5].setRightWall(true);
        boardSquares[7][5].setBottomWall(true);
        boardSquares[7][5].setIcons(bottomWall);
        boardSquares[8][6].setLeftWall(true);
        boardSquares[8][6].setIcons(leftWall);
        boardSquares[8][5].setSpecialSquare("multivortex");
        specials.add(boardSquares[8][5]);

        Icon blueCircle = new ImageIcon(((new ImageIcon("Resources/blueCircle.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[9][1].setIcons(blueCircle);
        boardSquares[9][1].setBottomWall(true);
        boardSquares[9][1].setRightWall(true);
        boardSquares[10][1].setTopWall(true);
        boardSquares[10][1].setIcons(topWall);
        boardSquares[9][2].setLeftWall(true);
        boardSquares[9][2].setIcons(leftWall);
        boardSquares[9][1].setSpecialSquare("blueCircle");
        specials.add(boardSquares[9][1]);

        Icon yellowSquare = new ImageIcon(((new ImageIcon("Resources/yellowSquare.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[9][14].setIcons(yellowSquare);
        boardSquares[9][14].setBottomWall(true);
        boardSquares[9][14].setRightWall(true);
        boardSquares[10][14].setTopWall(true);
        boardSquares[10][14].setIcons(topWall);
        boardSquares[9][15].setLeftWall(true);
        boardSquares[9][15].setIcons(leftWall);
        boardSquares[9][14].setSpecialSquare("yellowSquare");
        specials.add(boardSquares[9][14]);

        Icon greenSquare = new ImageIcon(((new ImageIcon("Resources/greenSquare.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[10][4].setIcons(greenSquare);
        boardSquares[10][4].setBottomWall(true);
        boardSquares[10][4].setLeftWall(true);
        boardSquares[11][4].setTopWall(true);
        boardSquares[11][4].setIcons(topWall);
        boardSquares[10][3].setRightWall(true);
        boardSquares[10][3].setIcons(rightWall);
        boardSquares[10][4].setSpecialSquare("greenSquare");
        specials.add(boardSquares[10][4]);

        Icon redTriangle = new ImageIcon(((new ImageIcon("Resources/redTriangle.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[10][8].setIcons(redTriangle);
        boardSquares[10][8].setTopWall(true);
        boardSquares[10][8].setRightWall(true);
        boardSquares[9][8].setBottomWall(true);
        boardSquares[9][8].setIcons(bottomWall);
        boardSquares[10][9].setLeftWall(true);
        boardSquares[10][9].setIcons(leftWall);
        boardSquares[10][8].setSpecialSquare("redTriangle");
        specials.add(boardSquares[10][8]);

        Icon greenCircle = new ImageIcon(((new ImageIcon("Resources/greenCircle.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[11][13].setIcons(greenCircle);
        boardSquares[11][13].setBottomWall(true);
        boardSquares[11][13].setLeftWall(true);
        boardSquares[12][13].setTopWall(true);
        boardSquares[12][13].setIcons(topWall);
        boardSquares[11][12].setRightWall(true);
        boardSquares[11][12].setIcons(rightWall);
        boardSquares[11][13].setSpecialSquare("greenCircle");
        specials.add(boardSquares[11][13]);

        Icon redStar = new ImageIcon(((new ImageIcon("Resources/redStar.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[13][5].setIcons(redStar);
        boardSquares[13][5].setTopWall(true);
        boardSquares[13][5].setRightWall(true);
        boardSquares[12][5].setBottomWall(true);
        boardSquares[12][5].setIcons(bottomWall);
        boardSquares[13][6].setLeftWall(true);
        boardSquares[13][6].setIcons(leftWall);
        boardSquares[13][5].setSpecialSquare("redStar");
        specials.add(boardSquares[13][5]);

        Icon blueStar = new ImageIcon(((new ImageIcon("Resources/blueStar.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[13][10].setIcons(blueStar);
        boardSquares[13][10].setTopWall(true);
        boardSquares[13][10].setLeftWall(true);
        boardSquares[12][10].setBottomWall(true);
        boardSquares[12][10].setIcons(bottomWall);
        boardSquares[13][9].setRightWall(true);
        boardSquares[13][9].setIcons(rightWall);
        boardSquares[13][10].setSpecialSquare("blueStar");
        specials.add(boardSquares[13][10]);

        Icon yellowTriangle = new ImageIcon(((new ImageIcon("Resources/yellowTriangle.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[14][3].setIcons(yellowTriangle);
        boardSquares[14][3].setTopWall(true);
        boardSquares[14][3].setLeftWall(true);
        boardSquares[13][3].setBottomWall(true);
        boardSquares[13][3].setIcons(bottomWall);
        boardSquares[14][2].setRightWall(true);
        boardSquares[14][2].setIcons(rightWall);
        boardSquares[14][3].setSpecialSquare("yellowTriangle");
        specials.add(boardSquares[14][3]);
    }

    //same as above method but with color vision assistance
    public void makeColorVisionSpecialSquares()
    {
        specials = new ArrayList<Square>();
        Icon leftWall = new ImageIcon(((new ImageIcon("Resources/Assisted/leftWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon topWall = new ImageIcon(((new ImageIcon("Resources/Assisted/topWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon bottomWall = new ImageIcon(((new ImageIcon("Resources/Assisted/bottomWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        Icon rightWall = new ImageIcon(((new ImageIcon("Resources/Assisted/rightWall.png")).getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));

        Icon redCircle = new ImageIcon(((new ImageIcon("Resources/Assisted/redCircle.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares[1][4].setIcons(redCircle);
        boardSquares[1][4].setTopWall(true);
        boardSquares[1][4].setLeftWall(true);
        boardSquares[0][4].setBottomWall(true);
        boardSquares[0][4].setIcons(bottomWall);
        boardSquares[1][3].setRightWall(true);
        boardSquares[1][3].setIcons(rightWall);
        boardSquares[1][4].setSpecialSquare("redCircle");
        specials.add(boardSquares[1][4]);

        Icon redSquare = new ImageIcon(((new ImageIcon("Resources/Assisted/redSquare.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares[1][13].setIcons(redSquare);
        boardSquares[1][13].setTopWall(true);
        boardSquares[1][13].setLeftWall(true);
        boardSquares[0][13].setBottomWall(true);
        boardSquares[0][13].setIcons(bottomWall);
        boardSquares[1][12].setRightWall(true);
        boardSquares[1][12].setIcons(rightWall);
        boardSquares[1][13].setSpecialSquare("redSquare");
        specials.add(boardSquares[1][13]);

        Icon greenTriangle = new ImageIcon(((new ImageIcon("Resources/Assisted/greenTriangle.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares[3][1].setIcons(greenTriangle);
        boardSquares[3][1].setTopWall(true);
        boardSquares[3][1].setRightWall(true);
        boardSquares[2][1].setBottomWall(true);
        boardSquares[2][1].setIcons(bottomWall);
        boardSquares[3][2].setLeftWall(true);
        boardSquares[3][2].setIcons(leftWall);
        boardSquares[3][1].setSpecialSquare("greenTriangle");
        specials.add(boardSquares[3][1]);

        Icon blueTriangle = new ImageIcon(((new ImageIcon("Resources/Assisted/blueTriangle.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        boardSquares[3][9].setIcons(blueTriangle);
        boardSquares[3][9].setBottomWall(true);
        boardSquares[3][9].setRightWall(true);
        boardSquares[4][9].setTopWall(true);
        boardSquares[4][9].setIcons(topWall);
        boardSquares[3][10].setLeftWall(true);
        boardSquares[3][10].setIcons(leftWall);
        boardSquares[3][9].setSpecialSquare("blueTriangle");
        specials.add(boardSquares[3][9]);

        Icon yellowStar = new ImageIcon(((new ImageIcon("Resources/Assisted/yellowStar.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[4][6].setIcons(yellowStar);
        boardSquares[4][6].setBottomWall(true);
        boardSquares[4][6].setRightWall(true);
        boardSquares[5][6].setTopWall(true);
        boardSquares[5][6].setIcons(topWall);
        boardSquares[4][7].setLeftWall(true);
        boardSquares[4][7].setIcons(leftWall);
        boardSquares[4][6].setSpecialSquare("yellowStar");
        specials.add(boardSquares[4][6]);

        Icon greenStar = new ImageIcon(((new ImageIcon("Resources/Assisted/greenStar.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[5][14].setIcons(greenStar);
        boardSquares[5][14].setBottomWall(true);
        boardSquares[5][14].setLeftWall(true);
        boardSquares[6][14].setTopWall(true);
        boardSquares[6][14].setIcons(topWall);
        boardSquares[5][13].setRightWall(true);
        boardSquares[5][13].setIcons(rightWall);
        boardSquares[5][14].setSpecialSquare("greenStar");
        specials.add(boardSquares[5][14]);

        Icon blueSquare = new ImageIcon(((new ImageIcon("Resources/Assisted/blueSquare.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[6][3].setIcons(blueSquare);
        boardSquares[6][3].setBottomWall(true);
        boardSquares[6][3].setLeftWall(true);
        boardSquares[7][3].setTopWall(true);
        boardSquares[7][3].setIcons(topWall);
        boardSquares[6][2].setRightWall(true);
        boardSquares[6][2].setIcons(rightWall);
        boardSquares[6][3].setSpecialSquare("blueSquare");
        specials.add(boardSquares[6][3]);

        Icon yellowCircle = new ImageIcon(((new ImageIcon("Resources/Assisted/yellowCircle.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));       
        boardSquares[6][11].setIcons(yellowCircle);
        boardSquares[6][11].setTopWall(true);
        boardSquares[6][11].setRightWall(true);
        boardSquares[5][11].setBottomWall(true);
        boardSquares[5][11].setIcons(bottomWall);
        boardSquares[6][12].setLeftWall(true);
        boardSquares[6][12].setIcons(leftWall);
        boardSquares[6][11].setSpecialSquare("yellowCircle");
        specials.add(boardSquares[6][11]);

        Icon multivortex = new ImageIcon(((new ImageIcon("Resources/Assisted/multivortex.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[8][5].setIcons(multivortex);
        boardSquares[8][5].setTopWall(true);
        boardSquares[8][5].setRightWall(true);
        boardSquares[7][5].setBottomWall(true);
        boardSquares[7][5].setIcons(bottomWall);
        boardSquares[8][6].setLeftWall(true);
        boardSquares[8][6].setIcons(leftWall);
        boardSquares[8][5].setSpecialSquare("multivortex");
        specials.add(boardSquares[8][5]);

        Icon blueCircle = new ImageIcon(((new ImageIcon("Resources/Assisted/blueCircle.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[9][1].setIcons(blueCircle);
        boardSquares[9][1].setBottomWall(true);
        boardSquares[9][1].setRightWall(true);
        boardSquares[10][1].setTopWall(true);
        boardSquares[10][1].setIcons(topWall);
        boardSquares[9][2].setLeftWall(true);
        boardSquares[9][2].setIcons(leftWall);
        boardSquares[9][1].setSpecialSquare("blueCircle");
        specials.add(boardSquares[9][1]);

        Icon yellowSquare = new ImageIcon(((new ImageIcon("Resources/Assisted/yellowSquare.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[9][14].setIcons(yellowSquare);
        boardSquares[9][14].setBottomWall(true);
        boardSquares[9][14].setRightWall(true);
        boardSquares[10][14].setTopWall(true);
        boardSquares[10][14].setIcons(topWall);
        boardSquares[9][15].setLeftWall(true);
        boardSquares[9][15].setIcons(leftWall);
        boardSquares[9][14].setSpecialSquare("yellowSquare");
        specials.add(boardSquares[9][14]);

        Icon greenSquare = new ImageIcon(((new ImageIcon("Resources/Assisted/greenSquare.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[10][4].setIcons(greenSquare);
        boardSquares[10][4].setBottomWall(true);
        boardSquares[10][4].setLeftWall(true);
        boardSquares[11][4].setTopWall(true);
        boardSquares[11][4].setIcons(topWall);
        boardSquares[10][3].setRightWall(true);
        boardSquares[10][3].setIcons(rightWall);
        boardSquares[10][4].setSpecialSquare("greenSquare");
        specials.add(boardSquares[10][4]);

        Icon redTriangle = new ImageIcon(((new ImageIcon("Resources/Assisted/redTriangle.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[10][8].setIcons(redTriangle);
        boardSquares[10][8].setTopWall(true);
        boardSquares[10][8].setRightWall(true);
        boardSquares[9][8].setBottomWall(true);
        boardSquares[9][8].setIcons(bottomWall);
        boardSquares[10][9].setLeftWall(true);
        boardSquares[10][9].setIcons(leftWall);
        boardSquares[10][8].setSpecialSquare("redTriangle");
        specials.add(boardSquares[10][8]);

        Icon greenCircle = new ImageIcon(((new ImageIcon("Resources/Assisted/greenCircle.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[11][13].setIcons(greenCircle);
        boardSquares[11][13].setBottomWall(true);
        boardSquares[11][13].setLeftWall(true);
        boardSquares[12][13].setTopWall(true);
        boardSquares[12][13].setIcons(topWall);
        boardSquares[11][12].setRightWall(true);
        boardSquares[11][12].setIcons(rightWall);
        boardSquares[11][13].setSpecialSquare("greenCircle");
        specials.add(boardSquares[11][13]);

        Icon redStar = new ImageIcon(((new ImageIcon("Resources/Assisted/redStar.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[13][5].setIcons(redStar);
        boardSquares[13][5].setTopWall(true);
        boardSquares[13][5].setRightWall(true);
        boardSquares[12][5].setBottomWall(true);
        boardSquares[12][5].setIcons(bottomWall);
        boardSquares[13][6].setLeftWall(true);
        boardSquares[13][6].setIcons(leftWall);
        boardSquares[13][5].setSpecialSquare("redStar");
        specials.add(boardSquares[13][5]);

        Icon blueStar = new ImageIcon(((new ImageIcon("Resources/Assisted/blueStar.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[13][10].setIcons(blueStar);
        boardSquares[13][10].setTopWall(true);
        boardSquares[13][10].setLeftWall(true);
        boardSquares[12][10].setBottomWall(true);
        boardSquares[12][10].setIcons(bottomWall);
        boardSquares[13][9].setRightWall(true);
        boardSquares[13][9].setIcons(rightWall);
        boardSquares[13][10].setSpecialSquare("blueStar");
        specials.add(boardSquares[13][10]);

        Icon yellowTriangle = new ImageIcon(((new ImageIcon("Resources/Assisted/yellowTriangle.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));        
        boardSquares[14][3].setIcons(yellowTriangle);
        boardSquares[14][3].setTopWall(true);
        boardSquares[14][3].setLeftWall(true);
        boardSquares[13][3].setBottomWall(true);
        boardSquares[13][3].setIcons(bottomWall);
        boardSquares[14][2].setRightWall(true);
        boardSquares[14][2].setIcons(rightWall);
        boardSquares[14][3].setSpecialSquare("yellowTriangle");
    }

    //sets the edges of the map as walls so the robots dont "fall off"
    public void setMapEdgeWall()
    {
        for(int column = 0; column < 16; column++)
        {
            boardSquares[column][0].setLeftWall(true);
        }

        for(int column = 0; column < 16; column++)
        {
            boardSquares[column][15].setRightWall(true);
        }

        for(int row = 0; row < 16; row++)
        {
            boardSquares[0][row].setTopWall(true);
        }

        for(int row = 0; row < 16; row++)
        {
            boardSquares[15][row].setBottomWall(true);
        }
    }

    //sets walls in the middle of the map so the robots dont go in it. This code 
    // be edited to show the special square the robots will need to go to
    public void makeMiddleSquares()
    {
        Icon black = new ImageIcon(((new ImageIcon("Resources/black.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));

        boardSquares[7][7].setIcons(black);
        boardSquares[7][7].setTopWall(true);
        boardSquares[7][7].setLeftWall(true);
        boardSquares[7][7].setBottomWall(true);
        boardSquares[7][7].setRightWall(true);
        boardSquares[6][7].setBottomWall(true);
        boardSquares[7][6].setRightWall(true);

        boardSquares[7][8].setIcons(black);
        boardSquares[7][8].setTopWall(true);
        boardSquares[7][8].setLeftWall(true);
        boardSquares[7][8].setBottomWall(true);
        boardSquares[7][8].setRightWall(true);
        boardSquares[6][8].setBottomWall(true);
        boardSquares[7][9].setLeftWall(true);

        boardSquares[8][7].setIcons(black);
        boardSquares[8][7].setTopWall(true);
        boardSquares[8][7].setLeftWall(true);
        boardSquares[8][7].setBottomWall(true);
        boardSquares[8][7].setRightWall(true);
        boardSquares[8][6].setRightWall(true);
        boardSquares[9][7].setTopWall(true);

        boardSquares[8][8].setIcons(black);
        boardSquares[8][8].setTopWall(true);
        boardSquares[8][8].setLeftWall(true);
        boardSquares[8][8].setBottomWall(true);
        boardSquares[8][8].setRightWall(true);
        boardSquares[9][8].setTopWall(true);
        boardSquares[8][9].setLeftWall(true);
    }

    //sets the robots on the board in a random space
    public void setRobot()
    {       
        ImageIcon red = new ImageIcon(((new ImageIcon("Resources/redRobot.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        ImageIcon yellow = new ImageIcon(((new ImageIcon("Resources/yellowRobot.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        ImageIcon blue = new ImageIcon(((new ImageIcon("Resources/blueRobot.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        ImageIcon green = new ImageIcon(((new ImageIcon("Resources/greenRobot.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));

        redRobot = new Robot(red);
        blueRobot = new Robot(blue);
        yellowRobot = new Robot(yellow);
        greenRobot = new Robot(green);

        int x = redRobot.getXCoord();
        int y = redRobot.getYCoord();
        rx = x;
        ry = y;
        Icon tempIcon = redRobot.getIcon();
        boardSquares[x][y].setIcons(tempIcon);
        boardSquares[x][y].setBackground(Color.RED);
        boardSquares[x][y].changeOccupied();

        x = yellowRobot.getXCoord();
        y = yellowRobot.getYCoord();
        yx = x;
        yy = y;
        tempIcon = yellowRobot.getIcon();
        boardSquares[x][y].setIcons(tempIcon);
        boardSquares[x][y].setBackground(Color.YELLOW);
        boardSquares[x][y].changeOccupied();

        x = greenRobot.getXCoord();
        y = greenRobot.getYCoord();
        gx = x;
        gy = y;
        tempIcon = greenRobot.getIcon();
        boardSquares[x][y].setIcons(tempIcon);
        boardSquares[x][y].setBackground(Color.GREEN);
        boardSquares[x][y].changeOccupied();

        x = blueRobot.getXCoord();
        y = blueRobot.getYCoord();
        bx = x;
        by = y;
        tempIcon = blueRobot.getIcon();
        boardSquares[x][y].setIcons(tempIcon);
        boardSquares[x][y].setBackground(Color.BLUE);
        boardSquares[x][y].changeOccupied();
    }

    //same as previous method but with color vision support
    public void setColorVisionRobot()
    {       
        ImageIcon red = new ImageIcon(((new ImageIcon("Resources/Assisted/redRobot.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        ImageIcon yellow = new ImageIcon(((new ImageIcon("Resources/Assisted/yellowRobot.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        ImageIcon blue = new ImageIcon(((new ImageIcon("Resources/Assisted/blueRobot.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
        ImageIcon green = new ImageIcon(((new ImageIcon("Resources/Assisted/greenRobot.png"))
                    .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));

        redRobot = new Robot(red);
        blueRobot = new Robot(blue);
        yellowRobot = new Robot(yellow);
        greenRobot = new Robot(green);

        int x = redRobot.getXCoord();
        int y = redRobot.getYCoord();
        rx = x;
        ry = y;
        Icon tempIcon = redRobot.getIcon();
        boardSquares[x][y].setIcons(tempIcon);
        boardSquares[x][y].setBackground(Color.GRAY);
        boardSquares[x][y].changeOccupied();

        x = yellowRobot.getXCoord();
        y = yellowRobot.getYCoord();
        yx = x;
        yy = y;
        tempIcon = yellowRobot.getIcon();
        boardSquares[x][y].setIcons(tempIcon);
        boardSquares[x][y].setBackground(Color.GRAY);
        boardSquares[x][y].changeOccupied();

        x = greenRobot.getXCoord();
        y = greenRobot.getYCoord();
        gx = x;
        gy = y;
        tempIcon = greenRobot.getIcon();
        boardSquares[x][y].setIcons(tempIcon);
        boardSquares[x][y].setBackground(Color.GRAY);
        boardSquares[x][y].changeOccupied();

        x = blueRobot.getXCoord();
        y = blueRobot.getYCoord();
        bx = x;
        by = y;
        tempIcon = blueRobot.getIcon();
        boardSquares[x][y].setIcons(tempIcon);
        boardSquares[x][y].setBackground(Color.GRAY);
        boardSquares[x][y].changeOccupied();
    }

    //place all robots in initial round positions for next player turn
    public void resetRobots()
    {
        Icon tempIcon = redRobot.getIcon();
        boardSquares[rx][ry].setIcons(tempIcon);
        boardSquares[rx][ry].setBackground(Color.RED);
        boardSquares[rx][ry].changeOccupied();

        tempIcon = yellowRobot.getIcon();
        boardSquares[yx][yy].setIcons(tempIcon);
        boardSquares[yx][yy].setBackground(Color.YELLOW);
        boardSquares[yx][yy].changeOccupied();

        tempIcon = greenRobot.getIcon();
        boardSquares[gx][gy].setIcons(tempIcon);
        boardSquares[gx][gy].setBackground(Color.GREEN);
        boardSquares[gx][gy].changeOccupied();

        tempIcon = blueRobot.getIcon();
        boardSquares[bx][by].setIcons(tempIcon);
        boardSquares[bx][by].setBackground(Color.BLUE);
        boardSquares[bx][by].changeOccupied();
        

    }

    //a mathod to change the icon on a given square on the board
    //This is mainly used to move the robot from on block to another by
    //replacing the image of the square on the board with that of the robot
    public static void changeIcon(int x, int y, Icon icon)
    {
        boardSquares[x][y].setIcons(icon);
        boardSquares[x][y].setIcon(icon);
    }

    //returns a particular square in the board
    public static Square getSquare(int x, int y)
    {
        return boardSquares[x][y];
    }

    public void changeSelectedRobotLabel(String color)
    {
        if(color.equals("none"))
            selectedRobot.setText("Robot selected: NONE");

        if(color.equals("red"))
            selectedRobot.setText("Robot selected: RED");

        if(color.equals("blue"))
            selectedRobot.setText("Robot selected: BLUE");

        if(color.equals("yellow"))
            selectedRobot.setText("Robot selected: YELLOW");

        if(color.equals("green"))
            selectedRobot.setText("Robot selected: GREEN");
    }

    //create players objects and store in array
    public void createPlayers()
    {
        for(int i = 0; i<num_of_players; i++)
        {
            int x = i + 1;
            String name = "Player " + x;
            players[i] = new Player(name);
        }
        lastPlayer = players[num_of_players-1];
    }

    //changes the player text to show who the current player is 
    public void changeCurrPlayer(String player)
    {
        currPlayer.setText(player);
    }

    //change the player score of a given int player
    public void changePlayerScore(int score, int player)
    {
        if(player == 1)
            player1.setText("Player 1: " + score);

        if(player == 2)
            player2.setText("Player 2: " + score);

        if(player == 3)
            player3.setText("Player 3: " + score);

        if(player == 4)
            player4.setText("Player 4: " + score);
    }

    //changes the moves text to show the total number of moves made by the current player
    public void changeMoves(int totalMoves)
    {
        moves.setText("Moves: " + totalMoves);
    }

    //return a list of all special squares
    public ArrayList<Square> getSpecialSquares()
    {
        return specials;
    }

    //start a new round
    public void newRound()
    {
        setRobot();
        newGoal();
        resetPlayers();
        changePlayer();

    }
    
    public void newColorRound()
    {
        setColorVisionRobot();
        newGoal();
        resetPlayers();
        changePlayer();
    }
    
    //reset all player moves to 0
    public void resetPlayers()
    {
        for (int i = 0; i < num_of_players; i++)
        {
            players[i].moveReset();
        }
    }

    //change player turn
    public void changePlayer()
    {
        totalMoves = 0;
        changeMoves(totalMoves);
        resetRobots();
        if (currentPlayer == null || currentPlayer == lastPlayer)
        {
            currentPlayer = players[0];
            changeCurrPlayer(currentPlayer.getName());
        }
        else if(currentPlayer.getName().equals("Player 1"))
        {
            currentPlayer = players[1];
            changeCurrPlayer(currentPlayer.getName());
        }
        else if(currentPlayer.getName().equals("Player 2"))
        {
            currentPlayer = players[2];
            changeCurrPlayer(currentPlayer.getName());
        }
        else if(currentPlayer.getName().equals("Player 3"))
        {
            currentPlayer = players[3];
            changeCurrPlayer(currentPlayer.getName());
        }
        else{noWinner();}
    }

    //display that round has no winner
    public void noWinner()
    {

    }

    //creates a new goal for players to reach
    public void newGoal()
    {
        int x = (int)(Math.random()*getSpecialSquares().size());
        setGoal(x);
        changeGoal(getSpecialSquares().get(x).getSpecialSquare());
        setObjective(getSpecialSquares().get(x).getSpecialSquare());
    }
    
    public void setGoal(int x)
    {
        getSpecialSquares().get(x).setIsGoal();
        Goal = getSpecialSquares().get(x);
    }
    
    public Square getGoal()
    {
        return Goal;
    }

    //changes the text to show the current goal for players
    public void changeGoal(String Goal)
    {
        goal.setText("Goal: " + Goal);
    }
    
    public void setObjective(String objective)
    {
        if(!MainMenu.isColorVision())
        {
            for(int i=1; i<=4; i++)
            {
                ImageIcon obj = new ImageIcon(((new ImageIcon("Resources/Middle/" + objective + i + ".png"))
                .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
                
                if(i==1)
                boardSquares[7][7].setIcons(obj);
                
                if(i==2)
                boardSquares[7][8].setIcons(obj);
                
                if(i==3)
                boardSquares[8][7].setIcons(obj);
                
                if(i==4)
                boardSquares[8][8].setIcons(obj);
            }
       }
       else
       {
           for(int i=1; i<=4; i++)
            {
                ImageIcon obj = new ImageIcon(((new ImageIcon("Resources/MiddleAssisted/" + objective + i + ".png"))
                .getImage()).getScaledInstance(43,43,java.awt.Image.SCALE_SMOOTH));
                
                if(i==1)
                boardSquares[7][7].setIcons(obj);
                
                if(i==2)
                boardSquares[7][8].setIcons(obj);
                
                if(i==3)
                boardSquares[8][7].setIcons(obj);
                
                if(i==4)
                boardSquares[8][8].setIcons(obj);
            }
       }
    }

    public void actionPerformed(ActionEvent aevt)
    {

    }


    public void mouseClicked(MouseEvent mevt)
    {
        Object selected = mevt.getSource();
        if(selected instanceof Square)
        {
            Square square = ((Square) selected);
            int x = square.getXCoord();
            int y = square.getYCoord();
            if ((x == redRobot.getXCoord() && y == redRobot.getYCoord())
            && (!blueRobot.isSelected() && !greenRobot.isSelected()
                && !yellowRobot.isSelected()))
            {
                redRobot.changeSelected();
                if (redRobot.isSelected())
                    changeSelectedRobotLabel("red");
                else
                    changeSelectedRobotLabel("none");
            }

            if (redRobot.isSelected() && (x == redRobot.getXCoord() ||
                y == redRobot.getYCoord()) && !(x ==redRobot.getXCoord() &&
                y == redRobot.getYCoord()))
            {
                redRobot.easyMove(x,y);
                totalMoves++;
                changeMoves(totalMoves);
                goalReached(redRobot.getXCoord(),redRobot.getYCoord(),"red");
            }

            if ((x == blueRobot.getXCoord() && y == blueRobot.getYCoord())
            && (!redRobot.isSelected() && !greenRobot.isSelected()
                && !yellowRobot.isSelected()))
            {
                blueRobot.changeSelected();
                if (blueRobot.isSelected())
                    changeSelectedRobotLabel("blue");
                else
                    changeSelectedRobotLabel("none");
            }

            if ((x == yellowRobot.getXCoord() && y == yellowRobot.getYCoord())
            && (!blueRobot.isSelected() && !greenRobot.isSelected()
                && !redRobot.isSelected()))
            {
                yellowRobot.changeSelected();
                if (yellowRobot.isSelected())
                    changeSelectedRobotLabel("yellow");
                else
                    changeSelectedRobotLabel("none");
            }

            if ((x == greenRobot.getXCoord() && y == greenRobot.getYCoord())
            && (!blueRobot.isSelected() && !redRobot.isSelected()
                && !yellowRobot.isSelected()))
            {
                greenRobot.changeSelected();
                if (greenRobot.isSelected())
                    changeSelectedRobotLabel("green");
                else
                    changeSelectedRobotLabel("none");
            }

            if (blueRobot.isSelected() && (x == blueRobot.getXCoord() ||
                y == blueRobot.getYCoord()) && !(x ==blueRobot.getXCoord() &&
                y == blueRobot.getYCoord()))
            {
                blueRobot.easyMove(x,y);
                totalMoves++;
                changeMoves(totalMoves);
                goalReached(blueRobot.getXCoord(),blueRobot.getYCoord(),"blue");
            }

            if (greenRobot.isSelected() && (x == greenRobot.getXCoord() ||
                y == greenRobot.getYCoord()) && !(x ==greenRobot.getXCoord() &&
                y == greenRobot.getYCoord()))
            {
                greenRobot.easyMove(x,y);
                totalMoves++;
                changeMoves(totalMoves);
                goalReached(greenRobot.getXCoord(),greenRobot.getYCoord(),"green");
            }

            if (yellowRobot.isSelected() && (x == yellowRobot.getXCoord() ||
                y == yellowRobot.getYCoord()) && !(x ==yellowRobot.getXCoord() &&
                y == yellowRobot.getYCoord()))
            {
                yellowRobot.easyMove(x,y);
                totalMoves++;
                changeMoves(totalMoves);
                goalReached(yellowRobot.getXCoord(),yellowRobot.getYCoord(),"yellow");
            }
        }
    }
   
    //check if current player has reached the goal
    public void goalReached(int x,int y,String color)
    {
        int gX = Goal.getXCoord();
        int gY = Goal.getYCoord();
        // for(int i = 0; i < getSpecialSquares().size(); i++)
        // {
            
        // }
        if((Goal.getSpecialSquare().contains(color)|| 
        Goal.getSpecialSquare().equals("multivortex")) && gX==x && gY==y)
        {
            currentPlayer.move(totalMoves);
            nextPlayer();
        }
    }
    
    public void nextPlayer()
    {
        if(currentPlayer == lastPlayer)
        {
            setWinner();
        }
        else{changePlayer();}
    }
    
    public void setWinner()
    {
        int lowest = maxMoves;
        for (int i =0; i < num_of_players; i ++)
        {
            if(players[i].getMoves()<lowest)
            {
                lowest = players[i].getMoves();
                roundWinner = players[i];
            }
        }
        roundWinner.setScore();
        setScores();
    }
    
    public void setScores()
    {
        for(int i = 0; i < num_of_players; i ++)
        {
            changePlayerScore(players[i].getScore(), i+1);
        }
        gameOver();
    }
    //display the results of the game and indicates the winner 
    //then return to main menu
    public void gameOver()
    {
        
    }

    public void mouseEntered(MouseEvent arg0){}

    public void mouseExited(MouseEvent arg0){}

    public void mousePressed(MouseEvent arg0){}

    public void mouseReleased(MouseEvent arg0){}

}
